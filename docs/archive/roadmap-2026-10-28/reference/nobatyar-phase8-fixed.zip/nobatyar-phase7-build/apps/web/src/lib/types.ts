export type Role = "PATIENT" | "DOCTOR" | "ADMIN";

export type AppointmentStatus =
  | "PENDING_PAYMENT" | "PENDING_CONFIRMATION" | "CONFIRMED" | "IN_PROGRESS" | "COMPLETED"
  | "CANCELLED_BY_PATIENT" | "CANCELLED_BY_DOCTOR" | "EXPIRED" | "NO_SHOW_PATIENT" | "NO_SHOW_DOCTOR";

export type AppointmentKind = "IN_PERSON" | "VIDEO" | "CHAT";

export interface Me {
  id: string;
  role: Role;
  phoneMasked: string;
  fullName: string;
  doctor: { isListed: boolean } | null;
  createdAt: string;
}

export interface Specialty { slug: string; nameFa: string }

export interface DoctorCard {
  id: string;
  fullName: string;
  bio: string | null;
  consultationFeeRial: string;
  slotMinutes: number;
  specialties: Specialty[];
}

export interface DoctorSearch { total: number; page: number; limit: number; items: DoctorCard[] }

export interface SlotsResponse { timezone: string; slotMinutes: number; slots: { startsAt: string; endsAt: string }[] }

export interface AppointmentItem {
  id: string;
  doctor: { id: string; fullName: string };
  patient: { id: string; fullName: string };
  startsAt: string;
  endsAt: string;
  status: AppointmentStatus;
  kind: AppointmentKind;
  priceRial: string;
  holdExpiresAt: string | null;
}
export interface AppointmentDetail extends AppointmentItem { reason: string | null }
export interface AppointmentList { items: AppointmentItem[]; nextCursor: string | null }

export interface ActionResult { id: string; status: AppointmentStatus; refundRial?: string }

export type VideoState = "OPEN" | "TOO_EARLY" | "ENDED" | "UNAVAILABLE" | "NOT_VIDEO";
export interface VideoStatus {
  available: boolean;
  state: VideoState;
  appointmentStatus: AppointmentStatus;
  role: "doctor" | "patient";
  opensAt: string | null;
  closesAt: string | null;
  peer: { fullName: string | null };
}
export interface VideoJoin {
  url: string;
  token: string;
  role: "doctor" | "patient";
  expiresAt: string;
  closesAt: string;
  peer: { fullName: string | null };
}

export interface Consent { type: string; version: string; grantedAt: string; revokedAt: string | null }

export interface WeeklyRule { weekday: number; startTime: string; endTime: string }
export interface AvailabilityResponse {
  settings: { slotMinutes: number; autoConfirm: boolean; consultationFeeRial: string; bio: string | null };
  rules: WeeklyRule[];
}
export interface TimeOff { id: string; startsAt: string; endsAt: string; reason: string | null }

export interface VerificationItem {
  id: string; doctorId: string; status: string; documentKey: string; createdAt: string;
  doctor: { fullName: string; medicalCouncilNo: string | null };
}

// ───────────── فاز ۸ ─────────────
export type Urgency = "EMERGENCY" | "URGENT" | "SOON" | "ROUTINE" | "SELF_CARE";
export interface TriageFlag { id: string; textFa: string; level: Urgency }
export interface TriageCatalog { complaints: { code: string; labelFa: string }[] }
export interface TriageResult {
  engineVersion: string; urgency: Urgency; reasonsFa: string[]; redFlagsHit: TriageFlag[];
  specialties: { slug: string; score: number }[]; adviceFa: string[];
  suggestedKind: "NONE" | "VIDEO" | "IN_PERSON" | "EMERGENCY";
  emergencyContacts: { number: string; labelFa: string }[]; disclaimerFa: string;
}
export interface TriageRun { id: string; result: TriageResult; doctors: { id: string; fullName: string; consultationFeeRial: string; specialties: Specialty[] }[] }

export interface HealthProfile {
  allergies: string[]; chronicConditions: string[]; medications: string[];
  bloodType: string | null; pregnancy: "NO" | "YES" | "UNKNOWN"; notes: string; updatedAt?: string | null;
  /** فقط برای نمای پزشک: false ⇒ پروفایل ثبت نشده/نامرئی (نه «بدون حساسیت»). */
  exists?: boolean;
}

export interface Diagnosis { code?: string; text: string }
export interface SoapContent { subjective: string; objective: string; assessment: string; plan: string; diagnoses: Diagnosis[]; followUpDays: number | null }
export type SoapView =
  | { exists: false; appointmentStatus: AppointmentStatus }
  | { exists: true; appointmentStatus: AppointmentStatus; status: "DRAFT" | "SIGNED"; version: number; signedAt: string | null; updatedAt: string;
      content: SoapContent; patientSummary: string; addenda: { id: string; createdAt: string; body: string }[] };
export interface VisitSummary { text: string; followUpDays: number | null; publishedAt: string; doctorName: string }

export interface RxItem { drugName: string; form?: string; strength?: string; dose: string; frequency: string; durationDays: number; quantity: number; instructions?: string }
export interface Prescription {
  id: string; number: string; appointmentId: string; status: "ACTIVE" | "EXPIRED" | "CANCELLED"; issuedAt: string; validUntil: string; cancelledAt: string | null;
  doctor: { fullName: string }; patient: { fullName: string }; items: RxItem[]; verifyCode?: string; allergyWarningAcknowledged?: boolean;
}
export interface AllergyWarning { drugName: string; allergen: string; reasonFa: string }

export type SoStatus = "REQUESTED" | "ACCEPTED" | "DECLINED" | "ANSWERED" | "EXPIRED" | "CANCELLED";
export interface SoListItem { id: string; status: SoStatus; createdAt: string; acceptDeadlineAt: string; answerDeadlineAt: string | null; respondedAt: string | null; doctorName?: string }
export interface SoAnswer { opinion: string; recommendations?: string; needsInPerson: boolean; urgency?: "ROUTINE" | "SOON" | "URGENT" }
export interface SoDetail {
  id: string; status: SoStatus; createdAt: string; acceptDeadlineAt: string; answerDeadlineAt: string | null; respondedAt: string | null;
  role: "doctor" | "patient"; doctorName?: string; includeVisitSummary: boolean; appointmentId?: string;
  request: { question: string; caseSummary: string; ageYears: number | null; gender: string | null };
  response: SoAnswer | null;
  records: { id: string; title: string; category: string; attachmentCount: number }[];
  visitSummary: { text: string; followUpDays: number | null } | null;
}
export interface SoCandidate { id: string; fullName: string; bio: string | null; specialties: Specialty[]; sameSpecialty: boolean }
