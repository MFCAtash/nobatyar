import "@fontsource-variable/vazirmatn";
import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Header } from "@/components/Header";
import { Providers } from "@/components/Providers";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "نوبت‌یار | رزرو نوبت پزشک", template: "%s | نوبت‌یار" },
  description: "جستجوی پزشک و رزرو نوبت آنلاین",
};

// تم پیش از اولین رنگ‌آمیزی اعمال می‌شود (جلوگیری از فلاش)
const themeScript = `try{var t=localStorage.getItem('nvy-theme');if(t==='light'||t==='dark')document.documentElement.setAttribute('data-theme',t)}catch(e){}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl" data-theme="dark" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body>
        <a className="skip-link" href="#main">رفتن به محتوا</a>
        <Providers>
          <Header />
          <main id="main" className="container page">{children}</main>
        </Providers>
      </body>
    </html>
  );
}
