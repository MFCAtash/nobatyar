"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { Loading, ErrorBox, Modal } from "@/components/ui";
import { errorMessage } from "@/lib/messages";

const CATEGORY_LABEL: Record<string, string> = {
  NOTE:             "یادداشت",
  LAB_RESULT:       "نتیجه آزمایش",
  IMAGING:          "تصویربرداری",
  PRESCRIPTION:     "نسخه",
  DISCHARGE_SUMMARY:"خلاصه ترخیص",
  REFERRAL:         "ارجاع",
  VACCINATION:      "واکسیناسیون",
  OTHER:            "سایر",
};
const CATEGORY_ICON: Record<string,string> = {
  NOTE:"📝", LAB_RESULT:"🧪", IMAGING:"🔬", PRESCRIPTION:"💊",
  DISCHARGE_SUMMARY:"🏥", REFERRAL:"📋", VACCINATION:"💉", OTHER:"📄",
};

interface RecordSummary {
  id: string; title: string; category: string;
  visitDate: string | null; tags: string[];
  attachmentCount: number; createdAt: string;
}

export default function RecordsPage() {
  const { api } = useAuth();
  const router  = useRouter();
  const [records,  setRecords]  = useState<RecordSummary[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [err,      setErr]      = useState<string|null>(null);
  const [hasMore,  setHasMore]  = useState(false);
  const [cursor,   setCursor]   = useState<string|null>(null);
  const [catFilter,setCatFilter]= useState<string>("");
  const [showAdd,  setShowAdd]  = useState(false);
  const [form,     setForm]     = useState({ title:"", content:"", category:"NOTE",
                                              visitDate:"", tags:"" });
  const [saving,   setSaving]   = useState(false);
  const [saveErr,  setSaveErr]  = useState<string|null>(null);

  const load = useCallback(async (cat: string, cur?: string) => {
    setLoading(true); setErr(null);
    try {
      const q = new URLSearchParams();
      if (cat) q.set("category", cat);
      if (cur) q.set("cursor", cur);
      const r = await api.get<{ records: RecordSummary[]; hasMore: boolean; cursor: string|null }>(
        `/records?${q.toString()}`
      );
      setRecords((p) => cur ? [...p, ...r.records] : r.records);
      setHasMore(r.hasMore);
      setCursor(r.cursor);
    } catch (e) { setErr(errorMessage(e)); }
    finally { setLoading(false); }
  }, [api]);

  useEffect(() => { load(catFilter); }, [load, catFilter]);

  const createRecord = async () => {
    setSaving(true); setSaveErr(null);
    try {
      const tags = form.tags.split(",").map(s=>s.trim()).filter(Boolean);
      await api.post("/records", {
        title:    form.title,
        content:  form.content,
        category: form.category,
        ...(form.visitDate ? { visitDate: form.visitDate } : {}),
        tags,
      });
      setShowAdd(false);
      setForm({ title:"", content:"", category:"NOTE", visitDate:"", tags:"" });
      load(catFilter);
    } catch (e) { setSaveErr(errorMessage(e)); }
    finally { setSaving(false); }
  };

  const fmtDate = (iso: string) =>
    new Intl.DateTimeFormat("fa-IR", {
      calendar:"persian", timeZone:"Asia/Tehran", dateStyle:"medium",
    }).format(new Date(iso));

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 700 }}>

        <div className="row between" style={{ marginBottom: 16 }}>
          <h2 style={{ margin:0 }}>پرونده سلامت</h2>
          <button className="btn btn-primary btn-sm" onClick={() => setShowAdd(true)}>
            + پرونده جدید
          </button>
        </div>

        {/* فیلتر دسته‌بندی */}
        <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:16 }}>
          {["", ...Object.keys(CATEGORY_LABEL)].map((cat) => (
            <button
              key={cat}
              className={`btn btn-sm ${catFilter === cat ? "btn-primary" : "btn-ghost"}`}
              onClick={() => { setCatFilter(cat); setRecords([]); }}
            >
              {cat ? `${CATEGORY_ICON[cat]} ${CATEGORY_LABEL[cat]}` : "همه"}
            </button>
          ))}
        </div>

        <ErrorBox message={err} />
        {loading && records.length === 0 && <Loading rows={4} />}

        {!loading && records.length === 0 && (
          <div className="empty">
            <div style={{ fontSize:48, marginBottom:12 }}>📋</div>
            <p>هیچ پرونده‌ای ثبت نشده</p>
            <button className="btn btn-primary" style={{ marginTop:12 }}
              onClick={() => setShowAdd(true)}>اولین پرونده را ایجاد کنید</button>
          </div>
        )}

        <div className="stack" style={{ gap:8 }}>
          {records.map((r) => (
            <Link
              key={r.id}
              href={`/records/${r.id}`}
              className="card row"
              style={{ gap:14, textDecoration:"none" }}
            >
              <span style={{ fontSize:26, flexShrink:0 }}>
                {CATEGORY_ICON[r.category] ?? "📄"}
              </span>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontWeight:700, marginBottom:3 }}>{r.title}</div>
                <div className="row" style={{ gap:8, flexWrap:"wrap" }}>
                  <span className="badge badge-info" style={{ fontSize:"0.72rem" }}>
                    {CATEGORY_LABEL[r.category] ?? r.category}
                  </span>
                  {r.visitDate && (
                    <span className="muted small">{fmtDate(r.visitDate)}</span>
                  )}
                  {r.attachmentCount > 0 && (
                    <span className="muted small">
                      📎 {r.attachmentCount.toLocaleString("fa-IR")} پیوست
                    </span>
                  )}
                </div>
                {r.tags.length > 0 && (
                  <div style={{ display:"flex", gap:4, flexWrap:"wrap", marginTop:5 }}>
                    {r.tags.map((t) => (
                      <span key={t} className="chip" style={{ fontSize:"0.7rem", padding:"1px 7px" }}>
                        {t}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <span className="muted small" style={{ flexShrink:0, fontSize:"0.72rem" }}>
                {fmtDate(r.createdAt)}
              </span>
            </Link>
          ))}
        </div>

        {hasMore && (
          <div className="center" style={{ marginTop:16 }}>
            <button className="btn" disabled={loading}
              onClick={() => load(catFilter, cursor ?? undefined)}>
              بیشتر
            </button>
          </div>
        )}

      </div>

      {/* Modal ایجاد پرونده */}
      {showAdd && (
        <Modal title="پرونده سلامت جدید" onClose={() => setShowAdd(false)}>
          <div className="stack" style={{ gap:12, marginTop:12 }}>
            <ErrorBox message={saveErr} />

            <div className="field">
              <label className="label">عنوان *</label>
              <input className="input" value={form.title}
                onChange={(e) => setForm(p=>({...p,title:e.target.value}))}
                placeholder="مثال: نتیجه آزمایش خون ۱۴۰۳/۰۷" />
            </div>

            <div className="field">
              <label className="label">دسته‌بندی</label>
              <select className="select" value={form.category}
                onChange={(e) => setForm(p=>({...p,category:e.target.value}))}>
                {Object.entries(CATEGORY_LABEL).map(([v,l]) => (
                  <option key={v} value={v}>{CATEGORY_ICON[v]} {l}</option>
                ))}
              </select>
            </div>

            <div className="field">
              <label className="label">توضیحات</label>
              <textarea className="input" rows={4} value={form.content}
                onChange={(e) => setForm(p=>({...p,content:e.target.value}))}
                placeholder="یادداشت‌های پزشکی، نتایج، نکات مهم…"
                style={{ resize:"vertical" }} />
            </div>

            <div className="field">
              <label className="label">تاریخ ویزیت (اختیاری)</label>
              <input className="input ltr" type="date" value={form.visitDate}
                onChange={(e) => setForm(p=>({...p,visitDate:e.target.value}))} />
            </div>

            <div className="field">
              <label className="label">برچسب‌ها (با کاما جدا کنید)</label>
              <input className="input" value={form.tags}
                onChange={(e) => setForm(p=>({...p,tags:e.target.value}))}
                placeholder="قلب، فشارخون، دیابت" />
            </div>

            <div className="row" style={{ gap:8, marginTop:4 }}>
              <button className="btn btn-primary" style={{ flex:1 }}
                disabled={saving || !form.title.trim()} onClick={createRecord}>
                {saving ? "در حال ذخیره…" : "ذخیره پرونده"}
              </button>
              <button className="btn btn-ghost" onClick={() => setShowAdd(false)}>انصراف</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
