"use client";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { formatToman } from "@/lib/format";
import { errorMessage } from "@/lib/messages";
import { ErrorBox, Loading } from "@/components/ui";

interface DoctorCompare {
  id: string; fullName: string; bio: string | null;
  consultationFeeRial: string; slotMinutes: number;
  city: string | null; onlineVisit: boolean; inPersonVisit: boolean;
  specialties: { slug: string; nameFa: string }[];
  workDays: number[];
}

const DAY_NAMES = ["یک‌شنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنج‌شنبه","جمعه","شنبه"];
const CHECK = "✓"; const CROSS = "✗";

function CompareTable({ doctors }: { doctors: DoctorCompare[] }) {
  const router = useRouter();
  const cols   = doctors.length;

  const row = (label: string, render: (d: DoctorCompare) => React.ReactNode) => (
    <tr>
      <td className="muted small" style={{ fontWeight: 600, padding: "10px 8px",
        borderBottom: "1px solid var(--border-soft)", width: 120 }}>
        {label}
      </td>
      {doctors.map((d) => (
        <td key={d.id} style={{ padding: "10px 12px",
          borderBottom: "1px solid var(--border-soft)", verticalAlign: "top" }}>
          {render(d)}
        </td>
      ))}
    </tr>
  );

  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 480 }}>
        <thead>
          <tr>
            <th style={{ width: 120 }}></th>
            {doctors.map((d) => (
              <th key={d.id} style={{ padding: "12px 12px 8px",
                borderBottom: "2px solid var(--border)", textAlign: "right" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div className="avatar" style={{ width: 36, height: 36, fontSize: "0.85rem" }}>
                    {d.fullName.replace(/^دکتر\s*/, "").charAt(0)}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: "0.9rem" }}>{d.fullName}</div>
                    <div className="muted small">{d.city}</div>
                  </div>
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {row("تخصص", (d) => (
            <div className="chips">
              {d.specialties.map((s) => (
                <span key={s.slug} className="badge badge-info" style={{ fontSize: "0.72rem" }}>
                  {s.nameFa}
                </span>
              ))}
            </div>
          ))}
          {row("هزینه ویزیت", (d) => (
            <strong className="num" style={{ color: "var(--teal)" }}>
              {formatToman(d.consultationFeeRial)}
            </strong>
          ))}
          {row("مدت ویزیت", (d) => (
            <span className="num">{d.slotMinutes.toLocaleString("fa-IR")} دقیقه</span>
          ))}
          {row("ویزیت آنلاین", (d) => (
            <span style={{ color: d.onlineVisit ? "var(--teal)" : "var(--red)" }}>
              {d.onlineVisit ? CHECK : CROSS}
            </span>
          ))}
          {row("ویزیت حضوری", (d) => (
            <span style={{ color: d.inPersonVisit ? "var(--teal)" : "var(--red)" }}>
              {d.inPersonVisit ? CHECK : CROSS}
            </span>
          ))}
          {row("روزهای کاری", (d) => (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
              {d.workDays.map((day) => (
                <span key={day} className="chip" style={{ padding: "2px 8px", fontSize: "0.72rem" }}>
                  {DAY_NAMES[day] ?? day}
                </span>
              ))}
            </div>
          ))}
          {row("بیوگرافی", (d) => (
            <p className="muted small" style={{ margin: 0, lineHeight: 1.7 }}>
              {d.bio ? d.bio.slice(0, 120) + (d.bio.length > 120 ? "…" : "") : "—"}
            </p>
          ))}
          <tr>
            <td></td>
            {doctors.map((d) => (
              <td key={d.id} style={{ padding: "12px 12px" }}>
                <Link className="btn btn-primary btn-sm btn-block" href={`/doctors/${d.id}`}>
                  رزرو نوبت
                </Link>
              </td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  );
}

function ComparePageInner() {
  const { api }  = useAuth();
  const params   = useSearchParams();
  const router   = useRouter();
  const ids      = params.get("ids") ?? "";
  const [doctors, setDoctors] = useState<DoctorCompare[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr]         = useState<string | null>(null);

  useEffect(() => {
    if (!ids) { setLoading(false); return; }
    api.get<DoctorCompare[]>(`/doctors/compare?ids=${ids}`)
      .then(setDoctors)
      .catch((e) => setErr(errorMessage(e)))
      .finally(() => setLoading(false));
  }, [api, ids]);

  if (!ids) {
    return (
      <div className="page">
        <div className="container">
          <div className="empty">
            <p>هیچ پزشکی برای مقایسه انتخاب نشده.</p>
            <button className="btn btn-primary" style={{ marginTop: 16 }}
              onClick={() => router.push("/")}>جستجوی پزشک</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="container">
        <div className="row between" style={{ marginBottom: 20 }}>
          <h2 style={{ margin: 0 }}>مقایسه پزشکان</h2>
          <button className="btn btn-ghost btn-sm" onClick={() => router.back()}>
            ← بازگشت
          </button>
        </div>

        <ErrorBox message={err} />
        {loading ? <Loading rows={6} /> : (
          doctors.length > 0
            ? <CompareTable doctors={doctors} />
            : <div className="empty">پزشکی یافت نشد</div>
        )}
      </div>
    </div>
  );
}

export default function ComparePage() {
  return (
    <Suspense fallback={<Loading rows={4} />}>
      <ComparePageInner />
    </Suspense>
  );
}
