"use client";
import { useNotifications } from "@/lib/use-notifications";
import { Loading } from "@/components/ui";

const KIND_ICON: Record<string, string> = {
  APPOINTMENT_REMINDER:  "🗓️",
  APPOINTMENT_CONFIRMED: "✅",
  APPOINTMENT_CANCELLED: "❌",
  PAYMENT_SUCCESS:       "💳",
  PAYMENT_FAILED:        "⚠️",
  SECOND_OPINION_READY:  "🔬",
  VIDEO_ROOM_READY:      "🎥",
  SYSTEM:                "🔔",
};

export default function NotificationsPage() {
  const { items, unread, loading, hasMore, markRead, markAllRead, loadMore } = useNotifications();

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 640 }}>

        <div className="row between" style={{ marginBottom: 16 }}>
          <h2 style={{ margin: 0 }}>
            اعلان‌ها
            {unread > 0 && (
              <span className="badge badge-warn num" style={{ marginRight: 8, fontSize: "0.75rem" }}>
                {unread.toLocaleString("fa-IR")}
              </span>
            )}
          </h2>
          {unread > 0 && (
            <button className="btn btn-ghost btn-sm" onClick={markAllRead}>
              همه را خوانده کن
            </button>
          )}
        </div>

        {loading && items.length === 0 && <Loading rows={4} />}

        {!loading && items.length === 0 && (
          <div className="empty">
            <div style={{ fontSize: 48, marginBottom: 12 }}>🔔</div>
            <p>هیچ اعلانی ندارید</p>
          </div>
        )}

        <div className="stack" style={{ gap: 8 }}>
          {items.map((n) => (
            <div
              key={n.id}
              className="card row"
              style={{
                gap: 12, cursor: n.readAt ? "default" : "pointer",
                opacity: n.readAt ? 0.75 : 1,
                borderColor: n.readAt ? "var(--border-soft)" : "var(--border)",
                background:  n.readAt ? "var(--glass)" : "var(--glass-strong)",
              }}
              onClick={() => { if (!n.readAt) markRead(n.id); }}
              role="button"
              tabIndex={n.readAt ? -1 : 0}
              onKeyDown={(e) => { if (!n.readAt && (e.key === "Enter" || e.key === " ")) markRead(n.id); }}
            >
              <span style={{ fontSize: 24, flexShrink: 0 }}>
                {KIND_ICON[n.kind] ?? "🔔"}
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, marginBottom: 2 }}>{n.titleFa}</div>
                <div className="muted small" style={{ lineHeight: 1.6 }}>{n.bodyFa}</div>
                <div className="muted small num ltr" style={{ marginTop: 4, fontSize: "0.7rem" }}>
                  {new Intl.DateTimeFormat("fa-IR", {
                    calendar: "persian",
                    dateStyle: "medium",
                    timeStyle: "short",
                    timeZone: "Asia/Tehran",
                  }).format(new Date(n.createdAt))}
                </div>
              </div>
              {!n.readAt && (
                <span
                  style={{
                    width: 8, height: 8, borderRadius: "50%",
                    background: "var(--teal)", flexShrink: 0,
                    boxShadow: "0 0 8px var(--teal-glow)",
                  }}
                  aria-label="خوانده‌نشده"
                />
              )}
            </div>
          ))}
        </div>

        {hasMore && (
          <div className="center" style={{ marginTop: 20 }}>
            <button className="btn" disabled={loading} onClick={loadMore}>
              {loading ? "در حال بارگذاری…" : "نمایش بیشتر"}
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
