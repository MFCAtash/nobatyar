"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { Loading, ErrorBox, Modal } from "@/components/ui";
import { errorMessage } from "@/lib/messages";

const MAX_MB = 20;

interface RecordDetail {
  id: string; title: string; content: string; category: string;
  visitDate: string | null; tags: string[]; createdAt: string; updatedAt: string;
  attachments: {
    id: string; fileName: string; mimeType: string; sizeBytes: number; createdAt: string;
  }[];
  shares: {
    id: string; doctorId: string; grantedAt: string; expiresAt: string | null;
    doctor: { fullName: string };
  }[];
}

function formatBytes(b: number) {
  if (b < 1024) return `${b} B`;
  if (b < 1024 * 1024) return `${(b/1024).toFixed(1)} KB`;
  return `${(b/1024/1024).toFixed(1)} MB`;
}

export default function RecordDetailPage() {
  const { id }    = useParams<{ id: string }>();
  const { api, me } = useAuth();
  const router    = useRouter();

  const [rec,       setRec]       = useState<RecordDetail | null>(null);
  const [loading,   setLoading]   = useState(true);
  const [err,       setErr]       = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [upErr,     setUpErr]     = useState<string | null>(null);
  const [shareModal,setShareModal]= useState(false);
  const [doctorId,  setDoctorId]  = useState("");
  const [expiresAt, setExpiresAt] = useState("");
  const [sharing,   setSharing]   = useState(false);
  const [shareErr,  setShareErr]  = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get<RecordDetail>(`/records/${id}`);
      setRec(r);
    } catch (e) { setErr(errorMessage(e)); }
    finally { setLoading(false); }
  }, [api, id]);

  useEffect(() => { load(); }, [load]);

  // ─── آپلود پیوست ─────────────────────────────────────────────────────────
  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > MAX_MB * 1024 * 1024) {
      setUpErr(`حداکثر ${MAX_MB} مگابایت`); return;
    }
    setUploading(true); setUpErr(null);
    try {
      // ۱. دریافت presigned URL
      const { objectKey, presignedPut } = await api.post<any>("/storage/upload-token", {
        bucket: "records", mime: file.type, bytes: file.size,
      });
      // ۲. آپلود مستقیم به MinIO
      const res = await fetch(presignedPut, {
        method: "PUT", body: file,
        headers: { "Content-Type": file.type },
      });
      if (!res.ok) throw new Error("آپلود ناموفق بود");
      // ۳. ثبت در API
      await api.post(`/records/${id}/attachments`, {
        objectKey, fileName: file.name, mimeType: file.type, sizeBytes: file.size,
      });
      load();
    } catch (err) { setUpErr(errorMessage(err)); }
    finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  // ─── دانلود پیوست ────────────────────────────────────────────────────────
  const downloadAtt = async (attId: string) => {
    try {
      const { url } = await api.get<{ url: string }>(
        `/records/attachments/${attId}/download`
      );
      window.open(url, "_blank", "noopener");
    } catch { alert("دریافت لینک ناموفق"); }
  };

  // ─── اشتراک‌گذاری ────────────────────────────────────────────────────────
  const doShare = async () => {
    if (!doctorId.trim()) { setShareErr("شناسه پزشک الزامی است"); return; }
    setSharing(true); setShareErr(null);
    try {
      await api.post(`/records/${id}/shares`, {
        doctorId: doctorId.trim(),
        ...(expiresAt ? { expiresAt: new Date(expiresAt).toISOString() } : {}),
      });
      setShareModal(false); setDoctorId(""); setExpiresAt("");
      load();
    } catch (e) { setShareErr(errorMessage(e)); }
    finally { setSharing(false); }
  };

  const revokeShare = async (shareId: string) => {
    if (!confirm("دسترسی این پزشک لغو شود؟")) return;
    try {
      await api.delete(`/records/${id}/shares/${shareId}`);
      load();
    } catch (e) { setErr(errorMessage(e)); }
  };

  const fmtDate = (iso: string) =>
    new Intl.DateTimeFormat("fa-IR", {
      calendar: "persian", timeZone: "Asia/Tehran",
      dateStyle: "medium", timeStyle: "short",
    }).format(new Date(iso));

  if (loading) return <div className="page"><div className="container"><Loading rows={5}/></div></div>;
  if (err)     return <div className="page"><div className="container"><ErrorBox message={err}/></div></div>;
  if (!rec)    return null;

  const isOwner = me?.role === "PATIENT";

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 720 }}>

        <div className="row between" style={{ marginBottom: 20 }}>
          <h2 style={{ margin: 0 }}>{rec.title}</h2>
          <button className="btn btn-ghost btn-sm" onClick={() => router.back()}>← بازگشت</button>
        </div>

        {/* محتوا */}
        {rec.content && (
          <div className="card" style={{ marginBottom: 16 }}>
            <div className="muted small" style={{ marginBottom: 8, fontWeight: 600 }}>
              محتوا
            </div>
            <p style={{ margin: 0, lineHeight: 1.85, whiteSpace: "pre-wrap" }}>{rec.content}</p>
          </div>
        )}

        {/* برچسب‌ها */}
        {rec.tags.length > 0 && (
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 }}>
            {rec.tags.map((t) => (
              <span key={t} className="chip" style={{ fontSize: "0.75rem" }}>{t}</span>
            ))}
          </div>
        )}

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 24 }}>

          {/* پیوست‌ها */}
          <div className="card">
            <div className="row between" style={{ marginBottom: 12 }}>
              <span style={{ fontWeight: 700 }}>📎 پیوست‌ها</span>
              {isOwner && (
                <>
                  <input
                    ref={fileRef} type="file" style={{ display: "none" }}
                    accept="image/*,.pdf,.doc,.docx,.txt,.xlsx"
                    onChange={handleUpload}
                  />
                  <button
                    className="btn btn-ghost btn-sm"
                    disabled={uploading}
                    onClick={() => fileRef.current?.click()}
                  >
                    {uploading ? "⏳" : "+ آپلود"}
                  </button>
                </>
              )}
            </div>
            <ErrorBox message={upErr} />
            {rec.attachments.length === 0 ? (
              <p className="muted small">پیوستی ندارد</p>
            ) : (
              <div className="stack" style={{ gap: 6 }}>
                {rec.attachments.map((a) => (
                  <button
                    key={a.id}
                    className="card row"
                    style={{
                      gap: 8, padding: "8px 10px", cursor: "pointer",
                      border: "1px solid var(--border-soft)",
                      borderRadius: 10, background: "var(--glass)",
                    }}
                    onClick={() => downloadAtt(a.id)}
                  >
                    <span style={{ fontSize: 18 }}>
                      {a.mimeType.startsWith("image/") ? "🖼️" : "📄"}
                    </span>
                    <div style={{ flex: 1, minWidth: 0, textAlign: "right" }}>
                      <div style={{
                        fontSize: "0.8rem", fontWeight: 600,
                        overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                      }}>
                        {a.fileName}
                      </div>
                      <div className="muted" style={{ fontSize: "0.7rem" }}>
                        {formatBytes(a.sizeBytes)}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* اشتراک‌گذاری */}
          {isOwner && (
            <div className="card">
              <div className="row between" style={{ marginBottom: 12 }}>
                <span style={{ fontWeight: 700 }}>👨‍⚕️ اشتراک با پزشک</span>
                <button className="btn btn-ghost btn-sm" onClick={() => setShareModal(true)}>
                  + اشتراک
                </button>
              </div>
              {rec.shares.length === 0 ? (
                <p className="muted small">با هیچ پزشکی به اشتراک گذاشته نشده</p>
              ) : (
                <div className="stack" style={{ gap: 6 }}>
                  {rec.shares.map((s) => (
                    <div key={s.id} className="row between"
                      style={{ padding: "6px 0", borderBottom: "1px solid var(--border-soft)" }}>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: "0.82rem" }}>
                          {s.doctor.fullName}
                        </div>
                        {s.expiresAt && (
                          <div className="muted" style={{ fontSize: "0.7rem" }}>
                            انقضا: {fmtDate(s.expiresAt)}
                          </div>
                        )}
                      </div>
                      <button
                        className="btn btn-danger btn-sm"
                        style={{ padding: "3px 8px", fontSize: "0.72rem" }}
                        onClick={() => revokeShare(s.id)}
                      >
                        لغو
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

      </div>

      {shareModal && (
        <Modal title="اشتراک‌گذاری با پزشک" onClose={() => setShareModal(false)}>
          <div className="stack" style={{ gap: 12, marginTop: 12 }}>
            <ErrorBox message={shareErr} />
            <div className="field">
              <label className="label">شناسه UUID پزشک *</label>
              <input className="input ltr" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                value={doctorId} onChange={(e) => setDoctorId(e.target.value)} />
              <span className="help">از صفحه پروفایل پزشک کپی کنید</span>
            </div>
            <div className="field">
              <label className="label">تاریخ انقضا (اختیاری)</label>
              <input className="input ltr" type="date"
                value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} />
            </div>
            <div className="row" style={{ gap: 8 }}>
              <button className="btn btn-primary" style={{ flex: 1 }}
                disabled={sharing} onClick={doShare}>
                {sharing ? "در حال ذخیره…" : "اشتراک‌گذاری"}
              </button>
              <button className="btn btn-ghost" onClick={() => setShareModal(false)}>انصراف</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
