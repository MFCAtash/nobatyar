"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useAuth } from "./auth-context";

export interface Notification {
  id:        string;
  kind:      string;
  titleFa:   string;
  bodyFa:    string;
  payload?:  Record<string, unknown>;
  readAt:    string | null;
  createdAt: string;
}

interface State {
  items:   Notification[];
  unread:  number;
  hasMore: boolean;
  cursor:  string | null;
  loading: boolean;
}

export function useNotifications() {
  const { api, status } = useAuth();
  const [state, setState] = useState<State>({
    items: [], unread: 0, hasMore: false, cursor: null, loading: false,
  });
  const esRef = useRef<EventSource | null>(null);

  // بارگذاری اولیه
  const load = useCallback(async (cursor?: string) => {
    if (status !== "authed") return;
    setState((s) => ({ ...s, loading: true }));
    try {
      const q = cursor ? `?cursor=${cursor}` : "";
      const r = await api.get<State>(`/notifications${q}`);
      setState((s) => ({
        items:   cursor ? [...s.items, ...r.items] : r.items,
        unread:  r.unread,
        hasMore: r.hasMore,
        cursor:  r.cursor,
        loading: false,
      }));
    } catch {
      setState((s) => ({ ...s, loading: false }));
    }
  }, [api, status]);

  useEffect(() => { load(); }, [load]);

  // SSE: اتصال به stream وقتی کاربر وارد است
  useEffect(() => {
    if (status !== "authed") return;

    // EventSource باید از همان مبدأ باشد (Next.js rewrite کرده /api/v1/*)
    const es = new EventSource("/api/v1/notifications/stream", { withCredentials: true });
    esRef.current = es;

    es.onmessage = (e) => {
      try {
        const notif: Notification = JSON.parse(e.data);
        setState((s) => ({
          ...s,
          items:  [notif, ...s.items],
          unread: s.unread + 1,
        }));
      } catch { /* نادیده */ }
    };

    es.onerror = () => {
      // reconnect خودکار توسط مرورگر انجام می‌شود
    };

    return () => { es.close(); esRef.current = null; };
  }, [status]);

  const markRead = useCallback(async (id: string) => {
    await api.patch(`/notifications/${id}/read`, {});
    setState((s) => ({
      ...s,
      items:  s.items.map((n) => n.id === id ? { ...n, readAt: new Date().toISOString() } : n),
      unread: Math.max(0, s.unread - 1),
    }));
  }, [api]);

  const markAllRead = useCallback(async () => {
    await api.patch("/notifications/read-all", {});
    setState((s) => ({
      ...s,
      items:  s.items.map((n) => ({ ...n, readAt: n.readAt ?? new Date().toISOString() })),
      unread: 0,
    }));
  }, [api]);

  const loadMore = useCallback(() => {
    if (state.cursor) load(state.cursor);
  }, [load, state.cursor]);

  return { ...state, markRead, markAllRead, loadMore };
}
