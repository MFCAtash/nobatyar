"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useNotifications } from "@/lib/use-notifications";

export function Header() {
  const { status, me, logout } = useAuth();
  const path = usePathname();
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const { unread } = useNotifications();

  useEffect(() => {
    const saved = (() => { try { return localStorage.getItem("nvy-theme"); } catch { return null; } })();
    const t = saved === "light" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", t);
    setTheme(t);
  }, []);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    try { localStorage.setItem("nvy-theme", next); } catch { /* حالت خصوصی */ }
    setTheme(next);
  };

  const link = (href: string, text: string, exact = false) => {
    const active = path === href
      || (!exact && href !== "/" && path.startsWith(`${href}/`))
      || (href === "/" && path.startsWith("/doctors/"));
    return <Link href={href} aria-current={active ? "page" : undefined}>{text}</Link>;
  };

  return (
    <header className="header">
      <div className="container">
        <Link href="/" className="brand">نوبت‌یار</Link>
        <nav className="nav" aria-label="منوی اصلی">
          {link("/", "جستجوی پزشک")}

          {/* ── بیمار ── */}
          {me?.role === "PATIENT" && (
            <>
              {link("/appointments",  "نوبت‌های من")}
              {link("/family",        "اعضای خانواده")}
              {link("/chat",          "پیام‌ها")}
              {link("/records",       "پرونده سلامت")}
              {link("/health-profile", "پروفایل سلامت")}
              {link("/triage",        "ارزیابی علائم")}
              {link("/prescriptions", "نسخه‌ها")}
              {link("/second-opinions", "نظر دوم")}
            </>
          )}

          {/* ── پزشک ── */}
          {me?.role === "DOCTOR" && (
            <>
              {link("/doctor",          "پنل پزشک",     true)}
              {link("/doctor/schedule", "برنامه‌ی کاری")}
              {link("/prescriptions", "نسخه‌ها")}
              {link("/second-opinions", "نظر دوم")}
            </>
          )}

          {/* ── ادمین ── */}
          {me?.role === "ADMIN" && link("/admin/verifications", "تأیید پزشکان")}

          {/* ── اعلان‌ها ── */}
          {status === "authed" && (
            <Link
              href="/notifications"
              aria-label={`اعلان‌ها${unread > 0 ? ` (${unread} خوانده‌نشده)` : ""}`}
              style={{ position: "relative", display: "inline-flex", alignItems: "center" }}
            >
              🔔
              {unread > 0 && (
                <span style={{
                  position: "absolute", top: -4, left: -4,
                  background: "var(--red)", color: "#fff",
                  borderRadius: "999px", fontSize: "0.6rem", fontWeight: 800,
                  minWidth: 16, height: 16, display: "flex",
                  alignItems: "center", justifyContent: "center",
                  padding: "0 3px", lineHeight: 1,
                }}>
                  {unread > 99 ? "۹۹+" : unread.toLocaleString("fa-IR")}
                </span>
              )}
            </Link>
          )}

          <button
            className="btn btn-ghost btn-sm"
            onClick={toggleTheme}
            aria-label="تغییر پوسته"
          >
            {theme === "dark" ? "☀️" : "🌙"}
          </button>

          {status === "authed" ? (
            <button className="btn btn-sm" onClick={() => void logout()}>خروج</button>
          ) : status === "anon" ? (
            <Link className="btn btn-primary btn-sm" href="/login">ورود / ثبت‌نام</Link>
          ) : null}
        </nav>
      </div>
    </header>
  );
}
