"use client";
import { useRouter, useSearchParams } from "next/navigation";
import { FormEvent, Suspense, useEffect, useState } from "react";
import { ErrorBox } from "@/components/ui";
import { ApiError } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import { safeNext, toAsciiDigits } from "@/lib/format";
import { errorMessage } from "@/lib/messages";

const RESEND_SEC = 60;

function LoginForm() {
  const { api, login, status, me } = useAuth();
  const router = useRouter();
  const next = safeNext(useSearchParams().get("next"), "");
  const [step, setStep] = useState<"phone" | "code">("phone");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [wait, setWait] = useState(0);

  // تنها منبع ریدایرکت پس از ورود (هم برای کاربر واردشده‌ی قبلی، هم بعد از verify) تا دو replace با هم رقابت نکنند
  useEffect(() => {
    if (status !== "authed" || !me) return;
    if (!me.fullName) return router.replace(`/onboarding${next ? `?next=${encodeURIComponent(next)}` : ""}`);
    router.replace(next || (me.role === "DOCTOR" ? "/doctor" : me.role === "ADMIN" ? "/admin/verifications" : "/"));
  }, [status, me, next, router]);
  useEffect(() => { if (wait <= 0) return; const t = setTimeout(() => setWait((w) => w - 1), 1000); return () => clearTimeout(t); }, [wait]);

  async function requestCode(e?: FormEvent) {
    e?.preventDefault();
    const p = toAsciiDigits(phone).replace(/\s+/g, "");
    if (!/^(\+?98|0)?9\d{9}$/.test(p)) return setErr("شماره‌ی موبایل معتبر نیست (مثال: ۰۹۱۲۱۲۳۴۵۶۷).");
    setBusy(true); setErr(null);
    try {
      await api.post("/auth/otp/request", { phone: p }, { auth: false });
      setStep("code"); setWait(RESEND_SEC);
    } catch (e2) {
      if (e2 instanceof ApiError && e2.retryAfterSec) { setWait(e2.retryAfterSec); if (e2.code === "too_many_requests") setStep("code"); }
      setErr(errorMessage(e2));
    } finally { setBusy(false); }
  }

  async function verify(e: FormEvent) {
    e.preventDefault();
    const c = toAsciiDigits(code).trim();
    if (!/^\d{6,8}$/.test(c)) return setErr("کد تأیید ۶ رقمی را وارد کنید.");
    setBusy(true); setErr(null);
    try {
      await login(toAsciiDigits(phone).replace(/\s+/g, ""), c); // ریدایرکت را effect بالا انجام می‌دهد
    } catch (e2) { setErr(errorMessage(e2)); setCode(""); } finally { setBusy(false); }
  }

  return (
    <div className="card stack" style={{ maxWidth: 420, margin: "40px auto" }}>
      <h1 style={{ fontSize: "1.5rem" }}>ورود یا ثبت‌نام</h1>
      {step === "phone" ? (
        <form className="stack" onSubmit={requestCode} noValidate>
          <div className="field">
            <label className="label" htmlFor="phone">شماره‌ی موبایل</label>
            <input id="phone" className="input ltr" inputMode="tel" autoComplete="tel" placeholder="09121234567" value={phone} onChange={(e) => setPhone(e.target.value)} autoFocus />
            <span className="help">کد تأیید به این شماره پیامک می‌شود. نیازی به رمز عبور نیست.</span>
          </div>
          <ErrorBox message={err} />
          <button className="btn btn-primary btn-block" disabled={busy}>{busy ? "در حال ارسال…" : "دریافت کد تأیید"}</button>
        </form>
      ) : (
        <form className="stack" onSubmit={verify} noValidate>
          <div className="field">
            <label className="label" htmlFor="code">کد تأیید ارسال‌شده به <span className="ltr num">{toAsciiDigits(phone)}</span></label>
            <input id="code" className="input otp" inputMode="numeric" autoComplete="one-time-code" maxLength={8} value={code} onChange={(e) => setCode(e.target.value)} autoFocus />
          </div>
          <ErrorBox message={err} />
          <button className="btn btn-primary btn-block" disabled={busy}>{busy ? "در حال بررسی…" : "ورود"}</button>
          <div className="row between small">
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setStep("phone"); setCode(""); setErr(null); }}>ویرایش شماره</button>
            <button type="button" className="btn btn-ghost btn-sm" disabled={wait > 0 || busy} onClick={() => void requestCode()}>
              {wait > 0 ? `ارسال مجدد تا ${wait.toLocaleString("fa-IR")} ثانیه` : "ارسال مجدد کد"}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

export default function LoginPage() {
  return <Suspense fallback={null}><LoginForm /></Suspense>;
}
