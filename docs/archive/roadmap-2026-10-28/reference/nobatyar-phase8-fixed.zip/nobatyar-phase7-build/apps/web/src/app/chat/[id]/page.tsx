"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import { useParams } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { useChat } from "@/hooks/use-chat";
import { errorMessage } from "@/lib/messages";

const MAX_FILE_MB = 20;

function formatBytes(b: number) {
  if (b < 1024)       return `${b} B`;
  if (b < 1024 * 1024) return `${(b/1024).toFixed(1)} KB`;
  return `${(b/1024/1024).toFixed(1)} MB`;
}

function formatTime(iso: string) {
  return new Intl.DateTimeFormat("fa-IR", {
    calendar:"persian", timeZone:"Asia/Tehran",
    hour:"2-digit", minute:"2-digit",
  }).format(new Date(iso));
}

function FileMessage({
  msg, isMe, onDownload,
}: {
  msg: any; isMe: boolean;
  onDownload: (msgId: string) => void;
}) {
  const isImage = msg.attachmentMime?.startsWith("image/");
  return (
    <button
      className="card"
      style={{
        padding: "8px 12px", cursor: "pointer",
        background: isMe ? "rgba(0,230,184,.15)" : "var(--glass-strong)",
        border: "1px solid var(--border-soft)",
        borderRadius: 12, textAlign: "right",
      }}
      onClick={() => onDownload(msg.id)}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 22 }}>{isImage ? "🖼️" : "📎"}</span>
        <div>
          <div style={{ fontWeight: 600, fontSize: "0.85rem" }}>
            {msg.attachmentName ?? "فایل"}
          </div>
          {msg.attachmentBytes && (
            <div className="muted" style={{ fontSize: "0.72rem" }}>
              {formatBytes(msg.attachmentBytes)}
            </div>
          )}
        </div>
      </div>
    </button>
  );
}

export default function ChatPage() {
  const { id: conversationId } = useParams<{ id: string }>();
  const { api, me }            = useAuth();

  const {
    messages, hasMore, loading, connected,
    typingUsers, sendText, sendFile, sendTyping, loadMore, markRead,
  } = useChat(conversationId);

  const [text,       setText]       = useState("");
  const [uploading,  setUploading]  = useState(false);
  const [uploadErr,  setUploadErr]  = useState<string | null>(null);
  const bottomRef   = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // اسکرول به پایین وقتی پیام جدید می‌آید
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  // علامت خوانده
  useEffect(() => {
    if (messages.length > 0) markRead();
  }, [messages.length, markRead]);

  const handleSend = () => {
    const t = text.trim();
    if (!t) return;
    sendText(t);
    setText("");
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > MAX_FILE_MB * 1024 * 1024) {
      setUploadErr(`حداکثر اندازه فایل ${MAX_FILE_MB} مگابایت است`);
      return;
    }
    setUploading(true);
    setUploadErr(null);
    try {
      await sendFile(file);
    } catch (err) {
      setUploadErr(errorMessage(err));
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleDownload = useCallback(async (msgId: string) => {
    try {
      const { url } = await api.get<{ url: string }>(`/conversations/messages/${msgId}/attachment`);
      window.open(url, "_blank", "noopener");
    } catch {
      alert("دریافت لینک دانلود ناموفق بود");
    }
  }, [api]);

  return (
    <div style={{
      display: "flex", flexDirection: "column",
      height: "calc(100vh - 64px)", direction: "rtl",
    }}>

      {/* ── نوار بالا ── */}
      <div style={{
        padding: "10px 16px", borderBottom: "1px solid var(--border-soft)",
        display: "flex", alignItems: "center", gap: 10,
        background: "var(--panel)", backdropFilter: "blur(12px)",
        flexShrink: 0,
      }}>
        <div style={{
          width: 9, height: 9, borderRadius: "50%", flexShrink: 0,
          background: connected ? "var(--teal)" : "var(--red)",
          boxShadow: connected ? "0 0 6px var(--teal-glow)" : "none",
          transition: "background .3s",
        }} />
        <span className="muted small">
          {connected ? "متصل" : "در حال اتصال مجدد…"}
        </span>
      </div>

      {/* ── ناحیه پیام‌ها ── */}
      <div style={{ flex: 1, overflowY: "auto", padding: "16px 16px 8px" }}>

        {hasMore && (
          <div style={{ textAlign: "center", marginBottom: 12 }}>
            <button className="btn btn-ghost btn-sm" disabled={loading} onClick={loadMore}>
              {loading ? "در حال بارگذاری…" : "پیام‌های قدیمی‌تر"}
            </button>
          </div>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {messages.map((msg) => {
            const isMe = msg.senderId === me?.id;
            return (
              <div
                key={msg.id}
                style={{
                  display: "flex",
                  justifyContent: isMe ? "flex-end" : "flex-start",
                }}
              >
                <div style={{
                  maxWidth: "72%",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: isMe ? "flex-end" : "flex-start",
                  gap: 3,
                }}>

                  {/* حباب پیام */}
                  {msg.kind === "TEXT" ? (
                    <div style={{
                      padding: "9px 14px",
                      background: isMe ? "rgba(0,230,184,.18)" : "var(--glass-strong)",
                      border: `1px solid ${isMe ? "rgba(0,230,184,.3)" : "var(--border-soft)"}`,
                      borderRadius: isMe ? "16px 4px 16px 16px" : "4px 16px 16px 16px",
                      fontSize: "0.9rem",
                      lineHeight: 1.65,
                      wordBreak: "break-word",
                    }}>
                      {msg.body}
                    </div>
                  ) : (
                    <FileMessage msg={msg} isMe={isMe} onDownload={handleDownload} />
                  )}

                  {/* زمان + وضعیت خوانده */}
                  <div style={{
                    display: "flex", alignItems: "center", gap: 5,
                    flexDirection: isMe ? "row-reverse" : "row",
                  }}>
                    <span className="muted" style={{ fontSize: "0.68rem" }}>
                      {formatTime(msg.createdAt)}
                    </span>
                    {isMe && (
                      <span style={{
                        fontSize: "0.72rem",
                        color: msg.readAt ? "var(--teal)" : "var(--muted)",
                      }}>
                        {msg.readAt ? "✓✓" : "✓"}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* تایپینگ */}
          {typingUsers.length > 0 && (
            <div style={{ display: "flex", justifyContent: "flex-start" }}>
              <div style={{
                padding: "8px 14px",
                background: "var(--glass-strong)",
                border: "1px solid var(--border-soft)",
                borderRadius: "4px 16px 16px 16px",
                display: "flex", gap: 4, alignItems: "center",
              }}>
                {[0,1,2].map((i) => (
                  <div key={i} style={{
                    width: 6, height: 6, borderRadius: "50%",
                    background: "var(--teal)",
                    animation: `bounce 1.2s ${i*0.2}s infinite`,
                  }}/>
                ))}
              </div>
            </div>
          )}
        </div>

        <div ref={bottomRef} />
      </div>

      {/* ── خطای آپلود ── */}
      {uploadErr && (
        <div style={{
          padding: "6px 16px", background: "rgba(255,84,112,.12)",
          color: "var(--red)", fontSize: "0.8rem", textAlign: "center",
          flexShrink: 0,
        }}>
          {uploadErr}
          <button
            style={{ marginRight: 8, color: "var(--red)", fontWeight: 700, cursor: "pointer", background: "none", border: "none" }}
            onClick={() => setUploadErr(null)}
          >✕</button>
        </div>
      )}

      {/* ── نوار ارسال ── */}
      <div style={{
        padding: "10px 12px",
        borderTop: "1px solid var(--border-soft)",
        background: "var(--panel)",
        backdropFilter: "blur(12px)",
        display: "flex", gap: 8, alignItems: "flex-end",
        flexShrink: 0,
      }}>
        {/* دکمه پیوست */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,.pdf,.doc,.docx,.txt"
          style={{ display: "none" }}
          onChange={handleFileChange}
        />
        <button
          className="btn btn-ghost"
          style={{ padding: "8px 10px", flexShrink: 0, fontSize: "1.1rem" }}
          disabled={uploading}
          onClick={() => fileInputRef.current?.click()}
          aria-label="پیوست فایل"
        >
          {uploading ? "⏳" : "📎"}
        </button>

        {/* textarea */}
        <textarea
          value={text}
          onChange={(e) => { setText(e.target.value); sendTyping(); }}
          onKeyDown={handleKey}
          placeholder="پیام بنویسید… (Enter برای ارسال)"
          rows={1}
          style={{
            flex: 1, resize: "none",
            background: "var(--glass-strong)",
            border: "1px solid var(--border-soft)",
            borderRadius: 12, padding: "10px 14px",
            color: "var(--ink)", fontSize: "0.9rem",
            fontFamily: "inherit", lineHeight: 1.5,
            maxHeight: 120, overflowY: "auto",
          }}
          onInput={(e) => {
            const el = e.currentTarget;
            el.style.height = "auto";
            el.style.height = Math.min(el.scrollHeight, 120) + "px";
          }}
        />

        {/* دکمه ارسال */}
        <button
          className="btn btn-primary"
          style={{ padding: "10px 16px", flexShrink: 0 }}
          disabled={!text.trim()}
          onClick={handleSend}
          aria-label="ارسال پیام"
        >
          ارسال
        </button>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-6px); }
        }
      `}</style>
    </div>
  );
}
