const API_URL = process.env.API_URL ?? "http://localhost:3000";

// آدرس عمومی LiveKit (همان LIVEKIT_URL سمت API). مرورگر مستقیم به آن وصل می‌شود، پس باید در CSP مجاز باشد.
// ws(s) برای سیگنالینگ؛ http(s) برای اعتبارسنجی/fallback ی کلاینت.
const LIVEKIT = (process.env.LIVEKIT_PUBLIC_URL ?? "").trim().replace(/\/+$/, "");
const lkOrigins = LIVEKIT && /^wss?:\/\//i.test(LIVEKIT)
  ? [LIVEKIT, LIVEKIT.replace(/^ws(s?):\/\//i, "http$1://")].join(" ")
  : "";

/** @type {import('next').NextConfig} */
export default {
  reactStrictMode: true,
  poweredByHeader: false,
  // API از همین مبدأ پروکسی می‌شود ⇒ کوکی refresh «same-origin» است (SameSite=Strict بدون دردسر CORS)
  async rewrites() {
    return [{ source: "/api/v1/:path*", destination: `${API_URL}/api/v1/:path*` }];
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(self), microphone=(self), geolocation=()" },
          // CSP پایه (Next بدون nonce به inline script نیاز دارد). CSP مبتنی بر nonce در فاز ۹.
          {
            key: "Content-Security-Policy",
            value: `default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'${lkOrigins ? " " + lkOrigins : ""}; media-src 'self' blob: mediastream:; worker-src 'self' blob:; font-src 'self' data:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'`,
          },
        ],
      },
    ];
  },
};
