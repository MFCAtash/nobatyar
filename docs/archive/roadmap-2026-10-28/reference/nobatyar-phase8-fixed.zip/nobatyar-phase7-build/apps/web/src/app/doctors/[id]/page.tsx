"use client";
import { useParams, useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ConsentDialog } from "@/components/ConsentDialog";
import { useToast } from "@/components/Toast";
import { ErrorBox, Loading } from "@/components/ui";
import { ApiError } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import { dayLabelFromDateStr, formatDateTime, formatNumber, formatTime, formatToman, nextTehranDays } from "@/lib/format";
import { errorMessage, KIND_LABEL } from "@/lib/messages";
import type { AppointmentDetail, AppointmentKind, DoctorCard, SlotsResponse } from "@/lib/types";

const DAYS_AHEAD = 7;

export default function DoctorPage() {
  const { id } = useParams<{ id: string }>();
  const { api, status, me } = useAuth();
  const router = useRouter();
  const toast = useToast();

  const days = useMemo(() => nextTehranDays(DAYS_AHEAD), []);
  const [doctor, setDoctor] = useState<DoctorCard | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [day, setDay] = useState(days[0]);
  const [slots, setSlots] = useState<SlotsResponse["slots"] | null>(null);
  const [slot, setSlot] = useState<string | null>(null);
  const [kind, setKind] = useState<AppointmentKind>("VIDEO");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [consentOpen, setConsentOpen] = useState(false);
  const seq = useRef(0);

  useEffect(() => {
    api.get<DoctorCard>(`/doctors/${id}`).then(setDoctor).catch((e) => { if (e instanceof ApiError && e.status === 404) setNotFound(true); else setErr(errorMessage(e)); });
  }, [api, id]);

  const loadSlots = useCallback(async (d: string) => {
    const my = ++seq.current;
    setSlots(null); setSlot(null);
    try {
      const r = await api.get<SlotsResponse>(`/doctors/${id}/slots?from=${d}&to=${d}`);
      if (my === seq.current) setSlots(r.slots);
    } catch (e) { if (my === seq.current) { setSlots([]); setErr(errorMessage(e)); } }
  }, [api, id]);
  useEffect(() => { void loadSlots(day); }, [day, loadSlots]);

  async function book() {
    if (!slot) return;
    if (status !== "authed") return router.push(`/login?next=${encodeURIComponent(`/doctors/${id}`)}`);
    setBusy(true); setErr(null);
    try {
      const a = await api.post<AppointmentDetail>("/appointments", { doctorId: id, startsAt: slot, kind, ...(reason.trim() ? { reason: reason.trim() } : {}) });
      toast("نوبت ثبت شد.", "ok");
      router.push(`/appointments/${a.id}`);
    } catch (e) {
      if (e instanceof ApiError && e.code === "consent_required") setConsentOpen(true);
      else {
        setErr(errorMessage(e));
        if (e instanceof ApiError && (e.code === "slot_taken" || e.code === "invalid_slot")) void loadSlots(day); // لیست تازه
      }
    } finally { setBusy(false); }
  }

  if (notFound) return <div className="empty">پزشک پیدا نشد.</div>;
  if (!doctor) return err ? <ErrorBox message={err} /> : <Loading />;

  const isPatientView = status !== "authed" || me?.role === "PATIENT";

  return (
    <div className="grid grid-2" style={{ alignItems: "start" }}>
      <section className="card stack">
        <div className="row">
          <div className="avatar" aria-hidden="true">{doctor.fullName.replace(/^دکتر\s*/, "").charAt(0)}</div>
          <div><h1 style={{ margin: 0, fontSize: "1.5rem" }}>{doctor.fullName}</h1>
            <div className="chips">{doctor.specialties.map((s) => <span key={s.slug} className="badge badge-info">{s.nameFa}</span>)}</div></div>
        </div>
        {doctor.bio && <p>{doctor.bio}</p>}
        <p className="muted small">هزینه‌ی ویزیت: <strong>{formatToman(doctor.consultationFeeRial)}</strong> · مدت هر نوبت {formatNumber(doctor.slotMinutes)} دقیقه</p>
      </section>

      <section className="card stack" aria-labelledby="book-h">
        <h2 id="book-h" style={{ fontSize: "1.2rem" }}>رزرو نوبت</h2>
        <div className="days" role="group" aria-label="روز">
          {days.map((d) => <button key={d} aria-pressed={d === day} className="chip" onClick={() => setDay(d)}>{dayLabelFromDateStr(d)}</button>)}
        </div>

        {slots === null ? <Loading rows={2} /> : slots.length === 0 ? <div className="empty">برای این روز وقت خالی وجود ندارد.</div> : (
          <div className="slot-grid" role="group" aria-label="ساعت‌های خالی">
            {slots.map((s) => <button key={s.startsAt} className="slot num" aria-pressed={slot === s.startsAt} onClick={() => setSlot(s.startsAt)}>{formatTime(s.startsAt)}</button>)}
          </div>
        )}

        {!isPatientView ? <div className="note-box">فقط حساب «بیمار» می‌تواند نوبت رزرو کند.</div> : slot && (
          <div className="stack">
            <div className="note-box">زمان انتخابی: <strong>{formatDateTime(slot)}</strong></div>
            <div className="field">
              <label className="label" htmlFor="kind">نوع ویزیت</label>
              <select id="kind" className="select" value={kind} onChange={(e) => setKind(e.target.value as AppointmentKind)}>
                {Object.entries(KIND_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div className="field">
              <label className="label" htmlFor="reason">دلیل مراجعه (اختیاری)</label>
              <textarea id="reason" className="textarea" maxLength={1000} value={reason} onChange={(e) => setReason(e.target.value)} />
              <span className="help">این متن رمزنگاری می‌شود و فقط پزشک همین نوبت آن را می‌بیند.</span>
            </div>
            <ErrorBox message={err} />
            <button className="btn btn-primary" disabled={busy} onClick={() => void book()}>{busy ? "در حال ثبت…" : status === "authed" ? "ثبت نوبت" : "ورود و ثبت نوبت"}</button>
          </div>
        )}
        {!slot && <ErrorBox message={err} />}
      </section>

      {consentOpen && <ConsentDialog onClose={() => setConsentOpen(false)} onGranted={() => { setConsentOpen(false); void book(); }} />}
    </div>
  );
}
