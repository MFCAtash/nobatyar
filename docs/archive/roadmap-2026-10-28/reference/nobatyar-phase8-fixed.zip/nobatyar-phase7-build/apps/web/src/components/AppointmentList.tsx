"use client";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { formatDateTime, formatToman } from "@/lib/format";
import { errorMessage } from "@/lib/messages";
import type { AppointmentItem, AppointmentList as ListResp } from "@/lib/types";
import { AppointmentActions } from "./AppointmentActions";
import { ErrorBox, kindLabel, Loading, StatusBadge } from "./ui";

/** فهرست نوبت‌ها با فیلتر دلخواه (query)، صفحه‌بندی با cursor و (برای پزشک) اقدام‌های سریع. */
export function AppointmentList({ query, counterpart, quickActions = false }: { query: string; counterpart: "doctor" | "patient"; quickActions?: boolean }) {
  const { api } = useAuth();
  const [items, setItems] = useState<AppointmentItem[] | null>(null);
  const [cursor, setCursor] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [loadingMore, setLoadingMore] = useState(false);
  const seq = useRef(0);

  const load = useCallback(async () => {
    const my = ++seq.current;
    setItems(null); setErr(null);
    try {
      const r = await api.get<ListResp>(`/appointments?${query}&limit=20`);
      if (my !== seq.current) return;
      setItems(r.items); setCursor(r.nextCursor);
    } catch (e) { if (my === seq.current) setErr(errorMessage(e)); }
  }, [api, query]);
  useEffect(() => { void load(); }, [load]);

  async function more() {
    if (!cursor) return;
    setLoadingMore(true);
    try {
      const r = await api.get<ListResp>(`/appointments?${query}&limit=20&cursor=${cursor}`);
      setItems((xs) => [...(xs ?? []), ...r.items]); setCursor(r.nextCursor);
    } catch (e) { setErr(errorMessage(e)); } finally { setLoadingMore(false); }
  }

  if (err) return <ErrorBox message={err} />;
  if (!items) return <Loading />;
  if (items.length === 0) return <div className="empty">نوبتی وجود ندارد.</div>;

  return (
    <div className="stack">
      {items.map((a) => (
        <div key={a.id} className="card stack" style={{ gap: 10 }}>
          <Link href={`/appointments/${a.id}`} className="row between">
            <div>
              <h3 style={{ margin: 0 }}>{counterpart === "doctor" ? a.doctor.fullName : a.patient.fullName || "بیمار"}</h3>
              <span className="muted small">{formatDateTime(a.startsAt)} · {kindLabel(a.kind)} · {formatToman(a.priceRial)}</span>
            </div>
            <StatusBadge status={a.status} />
          </Link>
          {quickActions && <AppointmentActions a={a} compact onDone={() => void load()} />}
        </div>
      ))}
      {cursor && <div className="center"><button className="btn" disabled={loadingMore} onClick={() => void more()}>نمایش بیشتر</button></div>}
    </div>
  );
}
