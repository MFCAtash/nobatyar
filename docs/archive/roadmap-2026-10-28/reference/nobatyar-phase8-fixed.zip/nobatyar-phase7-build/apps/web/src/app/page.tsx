"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { ErrorBox, Loading } from "@/components/ui";
import { useAuth } from "@/lib/auth-context";
import { formatToman } from "@/lib/format";
import { errorMessage } from "@/lib/messages";
import type { DoctorCard, DoctorSearch, Specialty } from "@/lib/types";

export default function HomePage() {
  const { api } = useAuth();
  const [q, setQ] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [items, setItems] = useState<DoctorCard[]>([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const seq = useRef(0);
  // ── مقایسه ──
  const [compare, setCompare] = useState<string[]>([]);
  const toggleCompare = (id: string) =>
    setCompare((p) => p.includes(id) ? p.filter((x) => x !== id) : p.length < 3 ? [...p, id] : p);

  useEffect(() => { api.get<Specialty[]>("/specialties").then(setSpecialties).catch(() => undefined); }, [api]);

  // جستجو با debounce؛ پاسخ‌های کهنه نادیده گرفته می‌شوند
  useEffect(() => {
    const my = ++seq.current;
    const t = setTimeout(async () => {
      setLoading(true); setErr(null);
      const params = new URLSearchParams({ page: String(page), limit: "12" });
      if (q.trim().length >= 2) params.set("q", q.trim());
      if (specialty) params.set("specialty", specialty);
      try {
        const r = await api.get<DoctorSearch>(`/doctors?${params}`);
        if (my !== seq.current) return;
        setItems((prev) => (page === 1 ? r.items : [...prev, ...r.items]));
        setTotal(r.total);
      } catch (e) { if (my === seq.current) setErr(errorMessage(e)); }
      finally { if (my === seq.current) setLoading(false); }
    }, q ? 300 : 0);
    return () => clearTimeout(t);
  }, [api, q, specialty, page]);

  const reset = (fn: () => void) => { fn(); setPage(1); };

  return (
    <>
      <section className="hero">
        <h1>پزشک مناسب را پیدا کنید و همین امروز نوبت بگیرید</h1>
        <p className="muted">ویزیت آنلاین و حضوری با پزشکان تأییدشده</p>
        <div className="searchbar" role="search">
          <input className="input" placeholder="نام پزشک…" aria-label="نام پزشک" value={q} onChange={(e) => reset(() => setQ(e.target.value))} />
          <select className="select" aria-label="تخصص" value={specialty} onChange={(e) => reset(() => setSpecialty(e.target.value))}>
            <option value="">همه‌ی تخصص‌ها</option>
            {specialties.map((s) => <option key={s.slug} value={s.slug}>{s.nameFa}</option>)}
          </select>
        </div>
      </section>

      <ErrorBox message={err} />
      {loading && items.length === 0 ? <Loading rows={4} /> : items.length === 0 ? (
        <div className="empty">پزشکی با این مشخصات پیدا نشد.</div>
      ) : (
        <>
          <p className="muted small">{total.toLocaleString("fa-IR")} پزشک</p>
          <div className="grid grid-3">
            {items.map((d) => (
              <div key={d.id} className="card stack" style={{ gap: 10, position:"relative" }}>
                <label style={{ position:"absolute", top:10, left:10,
                  display:"flex", alignItems:"center", gap:6, fontSize:"0.75rem",
                  color:"var(--muted)", cursor:"pointer", zIndex:2 }}>
                  <input type="checkbox"
                    checked={compare.includes(d.id)}
                    onChange={() => toggleCompare(d.id)}
                    style={{ accentColor:"var(--teal)" }}
                    aria-label={`${d.fullName} را به مقایسه اضافه کن`}
                  />
                  مقایسه
                </label>
                <Link key={d.id} href={`/doctors/${d.id}`} className="card stack" style={{ gap: 10, border:"none", padding:0, background:"transparent", boxShadow:"none" }}>
                <div className="row">
                  <div className="avatar" aria-hidden="true">{d.fullName.replace(/^دکتر\s*/, "").charAt(0)}</div>
                  <div><h3 style={{ margin: 0 }}>{d.fullName}</h3><span className="muted small">{formatToman(d.consultationFeeRial)} · {d.slotMinutes.toLocaleString("fa-IR")} دقیقه</span></div>
                </div>
                <div className="chips">{d.specialties.map((s) => <span key={s.slug} className="badge badge-info">{s.nameFa}</span>)}</div>
                {d.bio && <p className="muted small" style={{ margin: 0 }}>{d.bio.slice(0, 110)}{d.bio.length > 110 ? "…" : ""}</p>}
              </Link>
              </div>
            ))}
          </div>
          {items.length < total && (
            <div className="center" style={{ marginTop: 20 }}>
              <button className="btn" disabled={loading} onClick={() => setPage((p) => p + 1)}>نمایش بیشتر</button>
            </div>
          )}
        </>
      )}
      {compare.length >= 2 && (
        <div style={{
          position:"fixed", bottom:0, inset:0, top:"auto",
          background:"var(--panel)", borderTop:"1px solid var(--border)",
          padding:"12px 16px", display:"flex", alignItems:"center",
          justifyContent:"space-between", zIndex:50,
          backdropFilter:"blur(14px)",
        }}>
          <span className="muted small">{compare.length.toLocaleString("fa-IR")} پزشک انتخاب‌شده</span>
          <div style={{ display:"flex", gap:8 }}>
            <button className="btn btn-ghost btn-sm" onClick={() => setCompare([])}>پاک کردن</button>
            <a className="btn btn-primary btn-sm"
              href={`/compare?ids=${compare.join(",")}`}>
              مقایسه کن →
            </a>
          </div>
        </div>
      )}
    </>
  );
}
