"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { Loading, ErrorBox } from "@/components/ui";
import { errorMessage } from "@/lib/messages";

interface ConvSummary {
  id:            string;
  appointmentId: string;
  peer:          { userId: string; fullName: string };
  lastMessage:   {
    id: string; kind: string; senderId: string;
    bodyPreview: string; readAt: string | null; createdAt: string;
  } | null;
  unread:    number;
  createdAt: string;
}

export default function ChatListPage() {
  const { api } = useAuth();
  const [convs,   setConvs]   = useState<ConvSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [err,     setErr]     = useState<string | null>(null);

  useEffect(() => {
    api.get<ConvSummary[]>("/conversations")
      .then(setConvs)
      .catch((e) => setErr(errorMessage(e)))
      .finally(() => setLoading(false));
  }, [api]);

  const fmt = (iso: string) =>
    new Intl.DateTimeFormat("fa-IR", {
      calendar: "persian", timeZone: "Asia/Tehran",
      hour: "2-digit", minute: "2-digit",
    }).format(new Date(iso));

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 640 }}>
        <h2 style={{ marginBottom: 20 }}>پیام‌رسانی</h2>
        <ErrorBox message={err} />
        {loading && <Loading rows={4} />}
        {!loading && convs.length === 0 && (
          <div className="empty">
            <div style={{ fontSize: 48, marginBottom: 12 }}>💬</div>
            <p>هنوز مکالمه‌ای ندارید</p>
            <p className="muted small">پس از رزرو نوبت می‌توانید با پزشک پیام تبادل کنید</p>
          </div>
        )}
        <div className="stack" style={{ gap: 6 }}>
          {convs.map((c) => (
            <Link
              key={c.id}
              href={`/chat/${c.id}`}
              className="card row"
              style={{
                gap: 12, textDecoration: "none",
                background: c.unread > 0 ? "var(--glass-strong)" : "var(--glass)",
                borderColor: c.unread > 0 ? "var(--border)" : "var(--border-soft)",
              }}
            >
              {/* آواتار */}
              <div className="avatar" style={{ width: 46, height: 46, flexShrink: 0, fontSize: "1rem" }}>
                {c.peer.fullName.replace(/^دکتر\s*/,"").charAt(0)}
              </div>

              {/* محتوا */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="row between">
                  <span style={{ fontWeight: 700, fontSize: "0.93rem" }}>{c.peer.fullName}</span>
                  {c.lastMessage && (
                    <span className="muted" style={{ fontSize: "0.72rem" }}>
                      {fmt(c.lastMessage.createdAt)}
                    </span>
                  )}
                </div>
                <div className="row between" style={{ marginTop: 3 }}>
                  <span
                    className="muted"
                    style={{
                      fontSize: "0.82rem", overflow: "hidden",
                      textOverflow: "ellipsis", whiteSpace: "nowrap",
                      maxWidth: "200px",
                    }}
                  >
                    {c.lastMessage?.bodyPreview ?? "مکالمه جدید"}
                  </span>
                  {c.unread > 0 && (
                    <span style={{
                      background: "var(--teal)", color: "#022019",
                      borderRadius: "999px", fontSize: "0.65rem", fontWeight: 800,
                      minWidth: 18, height: 18, display: "flex",
                      alignItems: "center", justifyContent: "center", padding: "0 5px",
                    }}>
                      {c.unread.toLocaleString("fa-IR")}
                    </span>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
