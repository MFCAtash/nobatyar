"use client";
import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { errorMessage } from "@/lib/messages";
import { ErrorBox, Loading, Modal } from "@/components/ui";

const RELATIONS = ["فرزند", "والد", "همسر", "برادر", "خواهر", "سایر"];

interface Member {
  id: string; fullName: string; relation: string;
  birthYear?: number; nationalIdMasked?: string | null;
}

interface FormState {
  fullName: string; relation: string;
  birthYear: string; nationalId: string;
}
const EMPTY: FormState = { fullName: "", relation: RELATIONS[0], birthYear: "", nationalId: "" };

export default function FamilyPage() {
  const { api } = useAuth();
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr]         = useState<string | null>(null);
  const [modal, setModal]     = useState<"add" | "edit" | null>(null);
  const [editing, setEditing] = useState<Member | null>(null);
  const [form, setForm]       = useState<FormState>(EMPTY);
  const [saving, setSaving]   = useState(false);
  const [saveErr, setSaveErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setErr(null);
    try {
      const list = await api.get<Member[]>("/me/family");
      setMembers(list);
    } catch (e) { setErr(errorMessage(e)); }
    finally { setLoading(false); }
  }, [api]);

  useEffect(() => { load(); }, [load]);

  const openAdd  = () => { setForm(EMPTY); setEditing(null); setModal("add"); setSaveErr(null); };
  const openEdit = (m: Member) => {
    setForm({ fullName: m.fullName, relation: m.relation,
              birthYear: m.birthYear?.toString() ?? "", nationalId: "" });
    setEditing(m); setModal("edit"); setSaveErr(null);
  };

  const save = async () => {
    setSaving(true); setSaveErr(null);
    try {
      const body = {
        fullName:  form.fullName.trim(),
        relation:  form.relation,
        ...(form.birthYear   ? { birthYear:  parseInt(form.birthYear,  10) } : {}),
        ...(form.nationalId  ? { nationalId: form.nationalId }               : {}),
      };
      if (modal === "add") {
        const m = await api.post<Member>("/me/family", body);
        setMembers((p) => [...p, m]);
      } else if (editing) {
        const m = await api.patch<Member>(`/me/family/${editing.id}`, body);
        setMembers((p) => p.map((x) => x.id === m.id ? m : x));
      }
      setModal(null);
    } catch (e) { setSaveErr(errorMessage(e)); }
    finally { setSaving(false); }
  };

  const remove = async (id: string) => {
    if (!confirm("عضو خانواده حذف شود؟")) return;
    try {
      await api.delete(`/me/family/${id}`);
      setMembers((p) => p.filter((m) => m.id !== id));
    } catch (e) { setErr(errorMessage(e)); }
  };

  const field = (k: keyof FormState) => ({
    value:    form[k],
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm((p) => ({ ...p, [k]: e.target.value })),
  });

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 600 }}>

        <div className="row between" style={{ marginBottom: 16 }}>
          <h2 style={{ margin: 0 }}>اعضای خانواده</h2>
          <button className="btn btn-primary btn-sm" onClick={openAdd}>+ افزودن عضو</button>
        </div>
        <p className="muted small" style={{ marginBottom: 20 }}>
          می‌توانید برای اعضای خانواده نوبت بگیرید. اطلاعات کد ملی رمزنگاری‌شده ذخیره می‌شود.
        </p>

        <ErrorBox message={err} />

        {loading && <Loading rows={3} />}

        {!loading && members.length === 0 && (
          <div className="empty">
            <div style={{ fontSize: 48, marginBottom: 12 }}>👨‍👩‍👧</div>
            <p>هنوز عضوی اضافه نکرده‌اید</p>
          </div>
        )}

        <div className="stack" style={{ gap: 10 }}>
          {members.map((m) => (
            <div key={m.id} className="card row between" style={{ gap: 12 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div className="avatar" style={{ width: 44, height: 44, fontSize: "1rem" }}>
                  {m.fullName.replace(/\s+/g, "").charAt(0)}
                </div>
                <div>
                  <div style={{ fontWeight: 700 }}>{m.fullName}</div>
                  <div className="muted small">{m.relation}
                    {m.birthYear && ` · متولد ${m.birthYear.toLocaleString("fa-IR")}`}
                  </div>
                  {m.nationalIdMasked && (
                    <div className="muted small num ltr">کدملی: {m.nationalIdMasked}</div>
                  )}
                </div>
              </div>
              <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
                <button className="btn btn-ghost btn-sm" onClick={() => openEdit(m)}>ویرایش</button>
                <button className="btn btn-danger btn-sm"  onClick={() => remove(m.id)}>حذف</button>
              </div>
            </div>
          ))}
        </div>

      </div>

      {modal && (
        <Modal
          title={modal === "add" ? "افزودن عضو خانواده" : "ویرایش عضو"}
          onClose={() => setModal(null)}
        >
          <div className="stack" style={{ marginTop: 16, gap: 12 }}>
            <ErrorBox message={saveErr} />

            <div className="field">
              <label className="label">نام و نام‌خانوادگی *</label>
              <input className="input" placeholder="مثال: علی رضایی" {...field("fullName")} />
            </div>

            <div className="field">
              <label className="label">نسبت *</label>
              <select className="select" {...field("relation")}>
                {RELATIONS.map((r) => <option key={r}>{r}</option>)}
              </select>
            </div>

            <div className="field">
              <label className="label">سال تولد (شمسی)</label>
              <input className="input ltr" placeholder="مثال: ۱۳۷۰" type="number"
                min="1300" max="1420" {...field("birthYear")} />
            </div>

            <div className="field">
              <label className="label">کد ملی</label>
              <input className="input ltr" placeholder="۱۰ رقم" maxLength={10}
                pattern="\d{10}" {...field("nationalId")} />
              <span className="help">رمزنگاری‌شده ذخیره می‌شود</span>
            </div>

            <div className="row" style={{ gap: 8, marginTop: 4 }}>
              <button className="btn btn-primary" style={{ flex: 1 }}
                disabled={saving || !form.fullName.trim()} onClick={save}>
                {saving ? "در حال ذخیره…" : "ذخیره"}
              </button>
              <button className="btn btn-ghost" onClick={() => setModal(null)}>انصراف</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
