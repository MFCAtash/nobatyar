"use client";
import { useEffect, useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { errorMessage } from "@/lib/messages";
import { formatToman } from "@/lib/format";
import { ErrorBox, Loading } from "@/components/ui";

// ─── مرحله ۱: شروع پرداخت ────────────────────────────────────────────────
function InitiateView({ appointmentId }: { appointmentId: string }) {
  const { api } = useAuth();
  const [loading, setLoading] = useState(false);
  const [err, setErr]         = useState<string | null>(null);
  const [appt, setAppt]       = useState<any>(null);

  useEffect(() => {
    api.get(`/appointments/${appointmentId}`)
      .then(setAppt)
      .catch((e) => setErr(errorMessage(e)));
  }, [api, appointmentId]);

  const pay = async () => {
    setLoading(true); setErr(null);
    try {
      const callbackUrl = `${window.location.origin}/payment?appointmentId=${appointmentId}&step=verify`;
      const { paymentUrl } = await api.post<{ paymentUrl: string }>("/payments/initiate", {
        appointmentId,
        callbackUrl,
      });
      window.location.href = paymentUrl;
    } catch (e) {
      setErr(errorMessage(e));
      setLoading(false);
    }
  };

  if (!appt && !err) return <Loading rows={3} />;

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 480 }}>
        <h2>پرداخت نوبت</h2>
        <ErrorBox message={err} />

        {appt && (
          <div className="card stack" style={{ gap: 12, marginTop: 16 }}>
            <div className="row between">
              <span className="muted small">پزشک</span>
              <strong>{appt.doctor?.fullName}</strong>
            </div>
            <div className="row between">
              <span className="muted small">زمان</span>
              <strong className="num ltr">
                {new Intl.DateTimeFormat("fa-IR", {
                  calendar: "persian",
                  dateStyle: "medium",
                  timeStyle: "short",
                  timeZone: "Asia/Tehran",
                }).format(new Date(appt.startsAt))}
              </strong>
            </div>
            <div className="row between">
              <span className="muted small">مبلغ</span>
              <strong className="num" style={{ color: "var(--teal)", fontSize: "1.1rem" }}>
                {formatToman(appt.priceRial)}
              </strong>
            </div>
            <hr style={{ border: "none", borderTop: "1px solid var(--border-soft)" }} />
            <p className="muted small" style={{ margin: 0 }}>
              با کلیک روی «پرداخت»، به درگاه زرین‌پال منتقل می‌شوید.
              اطلاعات کارت شما هرگز در اختیار نوبت‌یار قرار نمی‌گیرد.
            </p>
            <button
              className="btn btn-primary btn-block"
              disabled={loading}
              onClick={pay}
            >
              {loading ? "در حال انتقال به درگاه…" : `پرداخت ${formatToman(appt.priceRial)}`}
            </button>
            <button
              className="btn btn-ghost btn-sm btn-block"
              onClick={() => history.back()}
            >
              انصراف
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── مرحله ۲: تأیید پس از بازگشت از درگاه ───────────────────────────────
function VerifyView({
  appointmentId,
  authority,
  status,
}: {
  appointmentId: string;
  authority: string;
  status: string;
}) {
  const { api } = useAuth();
  const router   = useRouter();
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);
  const [err, setErr]       = useState<string | null>(null);

  useEffect(() => {
    api.post<{ success: boolean; message: string }>("/payments/verify", {
      appointmentId,
      authority,
      status,
    })
      .then(setResult)
      .catch((e) => setErr(errorMessage(e)));
  }, [api, appointmentId, authority, status]);

  if (!result && !err) return <Loading rows={2} />;

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 420, textAlign: "center", paddingTop: 60 }}>
        {result?.success ? (
          <>
            <div style={{ fontSize: 64, marginBottom: 16 }}>✅</div>
            <h2>پرداخت موفق</h2>
            <p className="muted">{result.message}</p>
            <button
              className="btn btn-primary"
              style={{ marginTop: 24 }}
              onClick={() => router.push(`/appointments/${appointmentId}`)}
            >
              مشاهده نوبت
            </button>
          </>
        ) : (
          <>
            <div style={{ fontSize: 64, marginBottom: 16 }}>❌</div>
            <h2>پرداخت ناموفق</h2>
            <p className="muted">{result?.message ?? err}</p>
            <button
              className="btn btn-primary"
              style={{ marginTop: 24 }}
              onClick={() => router.push(`/payment?appointmentId=${appointmentId}`)}
            >
              تلاش مجدد
            </button>
            <button
              className="btn btn-ghost"
              style={{ marginTop: 8, display: "block", width: "100%" }}
              onClick={() => router.push("/appointments")}
            >
              بازگشت به نوبت‌هایم
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ─── صفحه اصلی پرداخت ─────────────────────────────────────────────────────
function PaymentPageInner() {
  const params        = useSearchParams();
  const appointmentId = params.get("appointmentId") ?? "";
  const step          = params.get("step");
  const authority     = params.get("Authority") ?? params.get("authority") ?? "";
  const status        = params.get("Status")    ?? params.get("status")    ?? "";

  if (!appointmentId) {
    return (
      <div className="page">
        <div className="container">
          <ErrorBox message="شناسه نوبت یافت نشد" />
        </div>
      </div>
    );
  }

  if (step === "verify") {
    return (
      <VerifyView
        appointmentId={appointmentId}
        authority={authority}
        status={status}
      />
    );
  }

  return <InitiateView appointmentId={appointmentId} />;
}

export default function PaymentPage() {
  return (
    <Suspense fallback={<Loading rows={3} />}>
      <PaymentPageInner />
    </Suspense>
  );
}
