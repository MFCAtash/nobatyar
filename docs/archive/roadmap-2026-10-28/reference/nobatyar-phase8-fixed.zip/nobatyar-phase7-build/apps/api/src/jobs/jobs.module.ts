import { Module } from "@nestjs/common";
import { AppointmentsModule } from "../appointments/appointments.module";
import { SecondOpinionModule } from "../second-opinion/second-opinion.module";
import { APPOINTMENT_NOTIFIER, NoopNotifier } from "../notifications/notifier";
import { AppointmentJobs } from "./appointment-jobs";
import { SchedulerService } from "./scheduler.service";

@Module({
  imports: [AppointmentsModule, SecondOpinionModule],
  providers: [AppointmentJobs, SchedulerService, { provide: APPOINTMENT_NOTIFIER, useClass: NoopNotifier }],
  exports: [AppointmentJobs, APPOINTMENT_NOTIFIER],
})
export class JobsModule {}
