import { Module } from "@nestjs/common";
import { Subject } from "rxjs";
import { PrismaModule } from "../prisma/prisma.module";
import { NotificationController } from "./notification.controller";
import { NotificationService, SSE_SUBJECTS } from "./notification.service";

@Module({
  imports: [PrismaModule],
  controllers: [NotificationController],
  providers: [
    {
      provide:  SSE_SUBJECTS,
      useValue: new Map<string, Subject<object>>(),
    },
    NotificationService,
  ],
  exports: [NotificationService],
})
export class NotificationModule {}
