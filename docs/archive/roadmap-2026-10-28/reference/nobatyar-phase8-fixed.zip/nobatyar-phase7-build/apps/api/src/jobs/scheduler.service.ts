import { Inject, Injectable, Logger, OnModuleDestroy, OnModuleInit } from "@nestjs/common";
import { SecondOpinionService } from "../second-opinion/second-opinion.service";
import { AppointmentJobs } from "./appointment-jobs";

/** BullMQ: یک job تکرارشونده (هر ۶۰ ثانیه). فقط وقتی ENABLE_WORKERS=true؛ برای اجرا در یک نمونه‌ی مجزا (worker). */
@Injectable()
export class SchedulerService implements OnModuleInit, OnModuleDestroy {
  private readonly log = new Logger(SchedulerService.name);
  private closers: Array<() => Promise<unknown>> = [];

  constructor(
    @Inject(AppointmentJobs) private readonly jobs: AppointmentJobs,
    @Inject(SecondOpinionService) private readonly secondOpinions: SecondOpinionService,
  ) {}

  async onModuleInit() {
    if (process.env.ENABLE_WORKERS !== "true") return;
    const url = process.env.REDIS_URL;
    if (!url) throw new Error("REDIS_URL is required when ENABLE_WORKERS=true");

    const { Queue, Worker } = await import("bullmq");
    const { default: IORedis } = await import("ioredis");
    const connection = new IORedis(url, { maxRetriesPerRequest: null });

    const queue = new Queue("maintenance", { connection });
    await queue.add("appointments-tick", {}, { repeat: { every: 60_000 }, jobId: "appointments-tick", removeOnComplete: 10, removeOnFail: 50 });
    const worker = new Worker("maintenance", async () => {
      await this.jobs.tick();
      await this.secondOpinions.expireStale(); // فاز ۸: انقضای نظر دوم بی‌پاسخ
    }, { connection, concurrency: 1 });
    worker.on("failed", (_job, err) => this.log.error(`maintenance job failed: ${err.message}`));

    this.closers = [() => worker.close(), () => queue.close(), async () => connection.quit()];
    this.log.log("maintenance worker started");
  }

  async onModuleDestroy() {
    await Promise.allSettled(this.closers.map((c) => c()));
  }
}
