/* داده‌ی مصنوعی توسعه — هرگز داده‌ی واقعی. اجرا: pnpm db:seed (با DATABASE_URL مالک) */
import { randomUUID } from "node:crypto";
import { PrismaClient } from "@prisma/client";
import { aad, FieldCrypto } from "../src/crypto/field-crypto";
import { normalizeIranMobile } from "../src/crypto/phone";

const prisma = new PrismaClient();
const crypto = FieldCrypto.fromEnv();

async function createUser(tx: Parameters<Parameters<PrismaClient["$transaction"]>[0]>[0], phone: string, role: "PATIENT" | "DOCTOR" | "ADMIN") {
  const norm = normalizeIranMobile(phone)!;
  const id = randomUUID();
  return tx.user.create({
    data: {
      id,
      role,
      phoneHash: crypto.blindIndex(norm, "phone"),
      phoneEnc: crypto.encrypt(norm, aad("users", id, "phone")),
    },
  });
}

async function main() {
  await prisma.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT set_config('app.role', 'SYSTEM', true)`;

    for (const [slug, nameFa] of [
      ["general", "پزشک عمومی"],
      ["cardiology", "قلب و عروق"],
      ["dermatology", "پوست و مو"],
      ["pediatrics", "کودکان"],
      // فاز ۸: هم‌خوان با کاتالوگ triage
      ["internal", "داخلی"], ["neurology", "مغز و اعصاب"], ["gastroenterology", "گوارش و کبد"], ["orthopedics", "ارتوپدی"],
      ["ent", "گوش، حلق و بینی"], ["urology", "کلیه و مجاری ادراری"], ["gynecology", "زنان و زایمان"], ["psychiatry", "روان‌پزشکی"],
      ["ophthalmology", "چشم‌پزشکی"], ["endocrinology", "غدد و متابولیسم"],
    ] as const) {
      await tx.specialty.upsert({ where: { slug }, update: {}, create: { slug, nameFa } });
    }

    const phoneHash = crypto.blindIndex(normalizeIranMobile("09120000001")!, "phone");
    if (await tx.user.findUnique({ where: { phoneHash } })) return console.log("seed already applied");

    const doc = await createUser(tx, "09120000001", "DOCTOR");
    await tx.doctorProfile.create({
      data: { userId: doc.id, fullName: "دکتر نمونه", consultationFeeRial: 3_000_000n, isListed: true },
    });
    const pat = await createUser(tx, "09120000002", "PATIENT");
    await tx.patientProfile.create({ data: { userId: pat.id, fullName: "بیمار نمونه" } });
    await createUser(tx, "09120000003", "ADMIN");
    console.log("seeded: 1 doctor, 1 patient, 1 admin (synthetic)");
  });
}

main().finally(() => prisma.$disconnect());
