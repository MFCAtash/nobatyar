import { Global, Module } from "@nestjs/common";
import Redis from "ioredis";
import { KV_STORE, RedisKv } from "./kv-store";

@Global()
@Module({
  providers: [
    {
      provide: KV_STORE,
      useFactory: () => {
        const url = process.env.REDIS_URL;
        if (!url) throw new Error("REDIS_URL is required");
        const client = new Redis(url, { maxRetriesPerRequest: 2, enableReadyCheck: true });
        return new RedisKv(client as unknown as ConstructorParameters<typeof RedisKv>[0]);
      },
    },
  ],
  exports: [KV_STORE],
})
export class RedisModule {}
