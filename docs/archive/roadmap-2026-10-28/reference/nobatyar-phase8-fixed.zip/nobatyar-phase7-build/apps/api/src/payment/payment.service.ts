import { randomUUID } from "node:crypto";
import {
  BadRequestException, ConflictException, ForbiddenException,
  Inject, Injectable, Logger, NotFoundException,
} from "@nestjs/common";
import { AuditService } from "../audit/audit.service";
import { PrismaService } from "../prisma/prisma.service";
import { NotificationService } from "../notifications/notification.service";
import type { InitiateInput, VerifyInput } from "./payment.schemas";
import type { AuthUser } from "../common/decorators";

const ALLOWED_STATUSES_FOR_PAYMENT = ["PENDING_PAYMENT"] as const;

@Injectable()
export class PaymentService {
  private readonly logger = new Logger(PaymentService.name);

  constructor(
    @Inject(PrismaService)        private readonly prisma:  PrismaService,
    @Inject(AuditService)         private readonly audit:   AuditService,
    @Inject(NotificationService)  private readonly notify:  NotificationService,
  ) {}

  /** @nestjs/config وابستگی پروژه نیست و توکن "CONFIG_SERVICE" هیچ‌جا ثبت نشده بود (اپ بالا نمی‌آمد)؛ مستقیم از env. */
  private readonly config = {
    get: <T = string>(key: string): T | undefined => {
      const v = process.env[key];
      return (v === undefined || v === "" ? undefined : v) as T | undefined;
    },
  };

  // ─── شروع پرداخت ──────────────────────────────────────────────────────────
  async initiate(user: AuthUser, dto: InitiateInput) {
    // اعتبارسنجی callbackUrl در برابر لیست سفید (open-redirect)
    const allowedOrigins = (this.config.get<string>("ALLOWED_CALLBACK_ORIGINS") ?? "")
      .split(",").map((s) => s.trim()).filter(Boolean);
    const origin = new URL(dto.callbackUrl).origin;
    if (allowedOrigins.length && !allowedOrigins.includes(origin)) {
      throw new BadRequestException("callbackUrl مجاز نیست");
    }

    return this.prisma.withContext({ role: user.role, userId: user.id }, async (tx) => {
      const appt = await tx.appointment.findUnique({
        where:  { id: dto.appointmentId },
        select: { id: true, patientId: true, status: true, priceRial: true },
      });
      if (!appt)                             throw new NotFoundException("نوبت یافت نشد");
      if (appt.patientId !== user.id)        throw new ForbiddenException();
      if (!ALLOWED_STATUSES_FOR_PAYMENT.includes(appt.status as any))
        throw new BadRequestException(`نوبت در وضعیت ${appt.status} قابل پرداخت نیست`);

      // idempotency: اگر پرداخت قبلی INITIATED دارد همان را برگردان
      const existing = await tx.payment.findUnique({
        where:  { appointmentId: dto.appointmentId },
        select: { id: true, gatewayRef: true, status: true },
      });
      if (existing?.status === "PAID") throw new ConflictException("این نوبت قبلاً پرداخت شده است");
      if (existing?.status === "INITIATED" && existing.gatewayRef) {
        return { paymentUrl: this._buildGatewayUrl(existing.gatewayRef, dto.callbackUrl) };
      }

      // ثبت درگاه (زرین‌پال sandbox)
      const authority = `SANDBOX-${randomUUID()}`;   // فاز ۶: درخواست واقعی به API درگاه
      const idempotencyKey = `appt-${dto.appointmentId}`;

      if (existing) {
        await tx.payment.update({
          where: { id: existing.id },
          data:  { gatewayRef: authority, status: "INITIATED" },
        });
      } else {
        await tx.payment.create({
          data: {
            appointmentId:  dto.appointmentId,
            amountRial:     appt.priceRial,
            gatewayRef:     authority,
            idempotencyKey,
            status:         "INITIATED",
          },
        });
      }

      await this.audit.record(tx, {
        actorId:    user.id,
        action:     "PAYMENT_INITIATED",
        resourceId: dto.appointmentId,
        meta:       { amountRial: appt.priceRial.toString() },
      });

      return { paymentUrl: this._buildGatewayUrl(authority, dto.callbackUrl) };
    });
  }

  // ─── تأیید پرداخت (callback از درگاه) ────────────────────────────────────
  async verify(user: AuthUser, dto: VerifyInput) {
    if (dto.status !== "OK") {
      // پرداخت لغو شد — وضعیت نوبت بدون تغییر می‌ماند
      return { success: false, message: "پرداخت توسط کاربر لغو شد" };
    }

    return this.prisma.withContext({ role: user.role, userId: user.id }, async (tx) => {
      const payment = await tx.payment.findFirst({
        where:  { appointmentId: dto.appointmentId, gatewayRef: dto.authority },
        select: { id: true, status: true, amountRial: true,
                  appointment: { select: { patientId: true, doctorId: true } } },
      });
      if (!payment)                     throw new NotFoundException("پرداخت یافت نشد");
      if (payment.appointment.patientId !== user.id) throw new ForbiddenException();
      if (payment.status === "PAID")    return { success: true, message: "پرداخت قبلاً ثبت شده است" };
      if (payment.status !== "INITIATED") throw new BadRequestException("وضعیت پرداخت نامعتبر است");

      // فاز ۶: تأیید واقعی از API درگاه با authority و amountRial
      const verified = true; // sandbox همیشه OK

      if (!verified) {
        await tx.payment.update({ where: { id: payment.id }, data: { status: "FAILED" } });
        await this.notify.push(user.id, {
          kind: "PAYMENT_FAILED", titleFa: "پرداخت ناموفق",
          bodyFa: "تراکنش توسط درگاه تأیید نشد. مبلغ در صورت کسر بازگشت می‌یابد.",
        });
        return { success: false, message: "تأیید درگاه ناموفق بود" };
      }

      // پرداخت موفق: Payment → PAID، Appointment → PENDING_CONFIRMATION
      await tx.payment.update({ where: { id: payment.id }, data: { status: "PAID" } });
      await tx.appointment.update({
        where: { id: dto.appointmentId },
        data:  { status: "PENDING_CONFIRMATION" },
      });
      await tx.appointmentStatusHistory.create({
        data: { appointmentId: dto.appointmentId, status: "PENDING_CONFIRMATION",
                changedById: user.id, note: "پرداخت تأیید شد" },
      });

      await this.audit.record(tx, {
        actorId:    user.id,
        action:     "PAYMENT_VERIFIED",
        resourceId: dto.appointmentId,
        meta:       { amountRial: payment.amountRial.toString() },
      });

      await this.notify.push(user.id, {
        kind: "PAYMENT_SUCCESS", titleFa: "پرداخت موفق",
        bodyFa: `پرداخت نوبت شما با موفقیت انجام شد.`,
        payload: { appointmentId: dto.appointmentId },
      });

      return { success: true, message: "پرداخت با موفقیت انجام شد" };
    });
  }

  // ─── وضعیت پرداخت یک نوبت ────────────────────────────────────────────────
  async getStatus(user: AuthUser, appointmentId: string) {
    return this.prisma.withContext({ role: user.role, userId: user.id }, async (tx) => {
      const payment = await tx.payment.findUnique({
        where:  { appointmentId },
        select: { id: true, status: true, amountRial: true, createdAt: true, updatedAt: true,
                  refunds: { select: { amountRial: true, reason: true, createdAt: true } } },
      });
      if (!payment) return null;
      const appt = await tx.appointment.findUnique({
        where:  { id: appointmentId },
        select: { patientId: true },
      });
      if (!appt || appt.patientId !== user.id) throw new ForbiddenException();
      return {
        ...payment,
        amountRial: payment.amountRial.toString(),
        refunds: payment.refunds.map((r) => ({ ...r, amountRial: r.amountRial.toString() })),
      };
    });
  }

  private _buildGatewayUrl(authority: string, callbackUrl: string): string {
    const base = this.config.get("ZARINPAL_SANDBOX") === "false"
      ? "https://www.zarinpal.com/pg/StartPay/"
      : "https://sandbox.zarinpal.com/pg/StartPay/";
    return `${base}${authority}?callback=${encodeURIComponent(callbackUrl)}`;
  }
}
