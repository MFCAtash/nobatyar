import {
  ForbiddenException, Inject, Injectable,
  Logger, NotFoundException, UnauthorizedException,
} from "@nestjs/common";
import type { Socket } from "socket.io";
import { FIELD_CRYPTO, FieldCrypto, aad } from "../crypto";
import { PrismaService } from "../prisma/prisma.service";
import { StorageService } from "../storage/storage.service";
import type { AuthUser } from "../common/decorators";
import { TokenService } from "../auth/token.service";
import type { MessageKind } from "@prisma/client";

interface SendDto {
  conversationId:  string;
  body?:           string;
  kind:            MessageKind;
  objectKey?:      string;
  attachmentName?: string;
  attachmentMime?: string;
  attachmentBytes?: number;
}

const PAGE_SIZE = 40;

@Injectable()
export class ChatService {
  private readonly logger = new Logger(ChatService.name);

  constructor(
    @Inject(PrismaService)    private readonly prisma:   PrismaService,
    @Inject(FIELD_CRYPTO)     private readonly crypto:   FieldCrypto,
    private readonly storage: StorageService,
    private readonly tokens:  TokenService,
  ) {}

  // ─── احراز هویت socket با JWT از query param ─────────────────────────────
  async authenticateSocket(socket: Socket): Promise<AuthUser> {
    const token = socket.handshake.auth?.token as string | undefined
      ?? socket.handshake.query?.token as string | undefined;
    if (!token) throw new UnauthorizedException();
    const payload = await this.tokens.verifyAccess(token).catch(() => null);
    if (!payload) throw new UnauthorizedException();
    return { id: payload.sub, role: payload.role };
  }

  // ─── conversation‌های یک کاربر ───────────────────────────────────────────
  async getUserConversationIds(userId: string): Promise<string[]> {
    const rows = await this.prisma.conversation.findMany({
      where: {
        OR: [{ patientId: userId }, { doctorId: userId }],
      },
      select: { id: true },
    });
    return rows.map((r) => r.id);
  }

  // ─── لیست conversation‌ها با آخرین پیام ───────────────────────────────────
  async listConversations(userId: string) {
    const convs = await this.prisma.conversation.findMany({
      where: { OR: [{ patientId: userId }, { doctorId: userId }] },
      include: {
        patient: { select: { userId: true, fullName: true } },
        doctor:  { select: { userId: true, fullName: true } },
        messages: {
          orderBy: { createdAt: "desc" },
          take: 1,
          select: {
            id: true, kind: true, senderId: true,
            bodyEnc: true, createdAt: true, readAt: true,
            attachmentName: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return Promise.all(convs.map(async (c) => {
      const last = c.messages[0];
      let lastBodyPreview = "";
      if (last) {
        if (last.kind === "TEXT") {
          try {
            lastBodyPreview = (await this.crypto.decrypt(last.bodyEnc, aad("msg", last.id.toString())))
              .toString("utf-8").slice(0, 60);
          } catch { lastBodyPreview = "…"; }
        } else {
          lastBodyPreview = `📎 ${last.attachmentName ?? "فایل"}`;
        }
      }

      const unread = await this.prisma.message.count({
        where: {
          conversationId: c.id,
          senderId: { not: userId },
          readAt: null,
        },
      });

      return {
        id:           c.id,
        appointmentId:c.appointmentId,
        peer:         c.patientId === userId ? c.doctor : c.patient,
        lastMessage:  last ? { ...last, id: last.id.toString(), bodyPreview: lastBodyPreview } : null,
        unread,
        createdAt:    c.createdAt,
      };
    }));
  }

  // ─── پیام‌های یک conversation (صفحه‌بندی cursor) ──────────────────────────
  async getMessages(
    userId: string,
    conversationId: string,
    cursor?: string,
  ) {
    await this._assertMember(userId, conversationId);

    const msgs = await this.prisma.message.findMany({
      where: {
        conversationId,
        deletedAt: null,
        ...(cursor ? { id: { lt: BigInt(cursor) } } : {}),
      },
      orderBy: { createdAt: "desc" },
      take: PAGE_SIZE + 1,
    });

    const hasMore = msgs.length > PAGE_SIZE;
    const page    = hasMore ? msgs.slice(0, PAGE_SIZE) : msgs;

    const decrypted = await Promise.all(page.map(async (m) => {
      let body = "";
      if (m.kind === "TEXT" || m.bodyEnc.length > 0) {
        try {
          body = (await this.crypto.decrypt(m.bodyEnc, aad("msg", m.id.toString())))
            .toString("utf-8");
        } catch { body = ""; }
      }
      return {
        id:             m.id.toString(),
        conversationId: m.conversationId,
        senderId:       m.senderId,
        kind:           m.kind,
        body,
        attachmentName: m.attachmentName,
        attachmentMime: m.attachmentMime,
        attachmentBytes:m.attachmentBytes,
        hasAttachment:  !!m.attachmentKey,
        readAt:         m.readAt,
        editedAt:       m.editedAt,
        createdAt:      m.createdAt,
      };
    }));

    // ترتیب صعودی برای رندر
    return {
      messages: decrypted.reverse(),
      hasMore,
      cursor: hasMore ? page[PAGE_SIZE - 1].id.toString() : null,
    };
  }

  // ─── ارسال پیام ────────────────────────────────────────────────────────────
  async createMessage(user: AuthUser, dto: SendDto) {
    await this._assertMember(user.id, dto.conversationId);

    // تأیید objectKey در MinIO
    if (dto.kind !== "TEXT" && dto.objectKey) {
      const bucket = "chat" as const;
      const head = await this.storage.headObject(bucket, dto.objectKey);
      if (!head) throw new ForbiddenException("فایل هنوز آپلود نشده است");
      // بررسی mime
      if (dto.attachmentMime && head.mime !== dto.attachmentMime)
        throw new ForbiddenException("نوع فایل با objectKey مطابقت ندارد");
    }

    const msgId = await this.prisma.$queryRaw<[{nextval:bigint}]>`SELECT nextval('messages_id_seq')`;
    const id    = msgId[0].nextval;

    const bodyBuf = Buffer.from(dto.body ?? "", "utf-8");
    const bodyEnc = dto.kind === "TEXT"
      ? await this.crypto.encrypt(bodyBuf, aad("msg", id.toString()))
      : Buffer.alloc(0);

    const msg = await this.prisma.message.create({
      data: {
        id,
        conversationId:  dto.conversationId,
        senderId:        user.id,
        kind:            dto.kind,
        bodyEnc,
        attachmentKey:   dto.objectKey,
        attachmentName:  dto.attachmentName,
        attachmentMime:  dto.attachmentMime,
        attachmentBytes: dto.attachmentBytes,
      },
    });

    return {
      id:             msg.id.toString(),
      conversationId: msg.conversationId,
      senderId:       msg.senderId,
      kind:           msg.kind,
      body:           dto.body ?? "",
      attachmentName: msg.attachmentName,
      attachmentMime: msg.attachmentMime,
      attachmentBytes:msg.attachmentBytes,
      hasAttachment:  !!msg.attachmentKey,
      createdAt:      msg.createdAt,
    };
  }

  // ─── علامت خوانده ─────────────────────────────────────────────────────────
  async markRead(userId: string, conversationId: string): Promise<void> {
    await this._assertMember(userId, conversationId);
    await this.prisma.message.updateMany({
      where: {
        conversationId,
        senderId: { not: userId },
        readAt:   null,
      },
      data: { readAt: new Date() },
    });
  }

  // ─── دریافت لینک دانلود فایل ─────────────────────────────────────────────
  async getAttachmentUrl(
    userId:    string,
    messageId: string,
  ): Promise<{ url: string; expiresAt: number }> {
    const msg = await this.prisma.message.findUnique({
      where:  { id: BigInt(messageId) },
      select: {
        attachmentKey: true, attachmentName: true,
        conversation: { select: { patientId: true, doctorId: true } },
      },
    });
    if (!msg?.attachmentKey) throw new NotFoundException("پیوست یافت نشد");
    const { patientId, doctorId } = msg.conversation;
    if (userId !== patientId && userId !== doctorId) throw new ForbiddenException();

    return this.storage.createDownloadUrl("chat", msg.attachmentKey, msg.attachmentName ?? "file");
  }

  // ─── بررسی عضویت در conversation ─────────────────────────────────────────
  private async _assertMember(userId: string, conversationId: string) {
    const conv = await this.prisma.conversation.findUnique({
      where:  { id: conversationId },
      select: { patientId: true, doctorId: true },
    });
    if (!conv) throw new NotFoundException("مکالمه یافت نشد");
    if (conv.patientId !== userId && conv.doctorId !== userId)
      throw new ForbiddenException("شما عضو این مکالمه نیستید");
    return conv;
  }
}
