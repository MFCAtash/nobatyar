import { Body, Controller, Get, Param, ParseUUIDPipe, Post, UseGuards } from "@nestjs/common";
import { JwtGuard } from "../auth/guards";
import { CurrentUser } from "../common/decorators";
import { ZodPipe } from "../common/zod.pipe";
import { PaymentService } from "./payment.service";
import { InitiateSchema, VerifySchema } from "./payment.schemas";
import type { AuthUser } from "../common/decorators";

@Controller("payments")
@UseGuards(JwtGuard)
export class PaymentController {
  constructor(private readonly svc: PaymentService) {}

  /** شروع پرداخت — دریافت لینک درگاه */
  @Post("initiate")
  initiate(
    @CurrentUser() user: AuthUser,
    @Body(new ZodPipe(InitiateSchema)) dto: any,
  ) {
    return this.svc.initiate(user, dto);
  }

  /** callback از درگاه پس از پرداخت */
  @Post("verify")
  verify(
    @CurrentUser() user: AuthUser,
    @Body(new ZodPipe(VerifySchema)) dto: any,
  ) {
    return this.svc.verify(user, dto);
  }

  /** وضعیت پرداخت یک نوبت */
  @Get(":appointmentId")
  status(
    @CurrentUser() user: AuthUser,
    @Param("appointmentId", new ParseUUIDPipe()) appointmentId: string,
  ) {
    return this.svc.getStatus(user, appointmentId);
  }
}
