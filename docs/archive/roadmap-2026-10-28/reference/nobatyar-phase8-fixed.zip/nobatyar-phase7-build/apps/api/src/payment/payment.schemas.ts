import { z } from "zod";

/** درگاه پرداخت فعلاً زرین‌پال — تنها درگاه فاز ۵ */
export const GATEWAY = "zarinpal" as const;

/** ورودی شروع پرداخت */
export const InitiateSchema = z.object({
  appointmentId: z.string().uuid(),
  /**
   * آدرس بازگشت پس از پرداخت — باید با ALLOWED_CALLBACK_ORIGINS تطابق داشته باشد
   * تا از open-redirect جلوگیری شود.
   */
  callbackUrl: z.string().url().max(512),
});
export type InitiateInput = z.infer<typeof InitiateSchema>;

/** وضعیت بازگشت از درگاه */
export const VerifySchema = z.object({
  appointmentId: z.string().uuid(),
  authority:     z.string().min(1).max(64),
  status:        z.string(),          // "OK" | "NOK"
});
export type VerifyInput = z.infer<typeof VerifySchema>;
