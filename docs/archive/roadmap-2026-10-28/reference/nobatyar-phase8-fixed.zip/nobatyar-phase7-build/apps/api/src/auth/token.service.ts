import { jwtVerify, SignJWT } from "jose";
import type { Role } from "@nobatyar/shared";
import { ROLES } from "@nobatyar/shared";
import type { AuthConfig } from "../config/auth.config";

const ISSUER = "nobatyar";
const AUDIENCE = "nobatyar-api";

export interface AccessClaims {
  sub: string;
  role: Role;
}

/** JWT دسترسی کوتاه‌مدت (HS256). الگوریتم، issuer و audience در تأیید اجباری‌اند. */
export class TokenService {
  constructor(private readonly cfg: Pick<AuthConfig, "accessSecret" | "accessTtlSec">) {}

  async signAccess(claims: AccessClaims): Promise<{ token: string; expiresInSec: number }> {
    const token = await new SignJWT({ role: claims.role })
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setSubject(claims.sub)
      .setIssuer(ISSUER)
      .setAudience(AUDIENCE)
      .setIssuedAt()
      .setExpirationTime(`${this.cfg.accessTtlSec}s`)
      .sign(this.cfg.accessSecret);
    return { token, expiresInSec: this.cfg.accessTtlSec };
  }

  /** null اگر نامعتبر/منقضی. */
  async verifyAccess(token: string): Promise<AccessClaims | null> {
    try {
      const { payload } = await jwtVerify(token, this.cfg.accessSecret, {
        algorithms: ["HS256"],
        issuer: ISSUER,
        audience: AUDIENCE,
        clockTolerance: 5,
      });
      const role = payload.role as Role;
      if (typeof payload.sub !== "string" || !ROLES.includes(role)) return null;
      return { sub: payload.sub, role };
    } catch {
      return null;
    }
  }
}
