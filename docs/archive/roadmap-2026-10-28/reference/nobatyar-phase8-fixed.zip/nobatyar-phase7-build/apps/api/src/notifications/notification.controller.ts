import {
  Controller, Get, Patch, Param, ParseUUIDPipe,
  Query, Res, UseGuards, Inject, Sse, MessageEvent,
} from "@nestjs/common";
import type { Response } from "express";
import { Observable, Subject } from "rxjs";
import { JwtGuard } from "../auth/guards";
import { CurrentUser } from "../common/decorators";
import type { AuthUser } from "../common/decorators";
import { NotificationService, SSE_SUBJECTS } from "./notification.service";

@Controller("notifications")
@UseGuards(JwtGuard)
export class NotificationController {
  constructor(
    private readonly svc:      NotificationService,
    @Inject(SSE_SUBJECTS)
    private readonly subjects: Map<string, Subject<object>>,
  ) {}

  /** SSE stream — کلاینت یک‌بار subscribe می‌کند */
  @Sse("stream")
  stream(
    @CurrentUser() user: AuthUser,
    @Res({ passthrough: false }) res: Response,
  ): Observable<MessageEvent> {
    let subj = this.subjects.get(user.id);
    if (!subj) {
      subj = new Subject<object>();
      this.subjects.set(user.id, subj);
    }

    // پاک‌سازی subject وقتی کلاینت قطع می‌کند
    res.on("close", () => {
      const s = this.subjects.get(user.id);
      if (s && s.observed === false) this.subjects.delete(user.id);
    });

    return subj.asObservable() as Observable<MessageEvent>;
  }

  /** لیست اعلان‌ها */
  @Get()
  list(
    @CurrentUser() user: AuthUser,
    @Query("unread") unread?: string,
    @Query("cursor") cursor?: string,
  ) {
    return this.svc.list(user.id, {
      unreadOnly: unread === "1",
      cursor,
    });
  }

  /** علامت یک اعلان خوانده */
  @Patch(":id/read")
  markRead(
    @CurrentUser() user: AuthUser,
    @Param("id", new ParseUUIDPipe()) id: string,
  ) {
    return this.svc.markRead(user.id, id);
  }

  /** همه را خوانده کن */
  @Patch("read-all")
  markAllRead(@CurrentUser() user: AuthUser) {
    return this.svc.markAllRead(user.id);
  }
}
