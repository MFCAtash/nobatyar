import {
  ConnectedSocket, MessageBody, OnGatewayConnection,
  OnGatewayDisconnect, SubscribeMessage, WebSocketGateway, WebSocketServer,
  WsException,
} from "@nestjs/websockets";
import type { Server, Socket } from "socket.io";
import { Inject, Logger, UseGuards } from "@nestjs/common";
import { WsJwtGuard } from "../auth/guards";
import { PrismaService } from "../prisma/prisma.service";
import { ChatService } from "./chat.service";
import type { AuthUser } from "../common/decorators";
import { z } from "zod";

const SendMessageSchema = z.object({
  conversationId: z.string().uuid(),
  body:           z.string().max(4000).optional().default(""),
  kind:           z.enum(["TEXT","FILE","IMAGE"]).default("TEXT"),
  objectKey:      z.string().max(500).optional(),
  attachmentName: z.string().max(255).optional(),
  attachmentMime: z.string().max(80).optional(),
  attachmentBytes:z.number().int().optional(),
});

const ReadSchema = z.object({
  conversationId: z.string().uuid(),
  messageId:      z.string(),
});

const TypingSchema = z.object({
  conversationId: z.string().uuid(),
  typing:         z.boolean(),
});

@WebSocketGateway({
  namespace: "/chat",
  cors: {
    origin:      process.env.WEB_ORIGIN ?? "http://localhost:3001",
    credentials: true,
  },
  transports: ["websocket"],
})
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() private readonly io!: Server;
  private readonly logger = new Logger(ChatGateway.name);

  /** Map: userId → Set<socketId> */
  private readonly userSockets = new Map<string, Set<string>>();

  constructor(
    @Inject(PrismaService) private readonly prisma: PrismaService,
    private readonly chatSvc: ChatService,
  ) {}

  // ─── اتصال ─────────────────────────────────────────────────────────────────
  async handleConnection(socket: Socket) {
    try {
      const user = await this.chatSvc.authenticateSocket(socket);
      (socket as any).user = user;
      socket.join(`user:${user.id}`);

      // join اتاق‌های conversation
      const convIds = await this.chatSvc.getUserConversationIds(user.id);
      convIds.forEach((id) => socket.join(`conv:${id}`));

      if (!this.userSockets.has(user.id)) this.userSockets.set(user.id, new Set());
      this.userSockets.get(user.id)!.add(socket.id);

      this.logger.log(`connect: ${user.id} (${socket.id})`);
    } catch {
      socket.disconnect(true);
    }
  }

  // ─── قطع اتصال ─────────────────────────────────────────────────────────────
  handleDisconnect(socket: Socket) {
    const user: AuthUser | undefined = (socket as any).user;
    if (!user) return;
    const sockets = this.userSockets.get(user.id);
    if (sockets) {
      sockets.delete(socket.id);
      if (sockets.size === 0) this.userSockets.delete(user.id);
    }
    this.logger.log(`disconnect: ${user.id} (${socket.id})`);
  }

  // ─── ارسال پیام ────────────────────────────────────────────────────────────
  @SubscribeMessage("send_message")
  async onSendMessage(
    @ConnectedSocket() socket: Socket,
    @MessageBody() raw: unknown,
  ) {
    const user: AuthUser = (socket as any).user;
    if (!user) throw new WsException("unauthorized");

    const parsed = SendMessageSchema.safeParse(raw);
    if (!parsed.success) throw new WsException("invalid payload");

    const dto = parsed.data;

    // تأیید آپلود فایل (objectKey باید وجود داشته باشد)
    if (dto.kind !== "TEXT" && !dto.objectKey)
      throw new WsException("objectKey برای پیام فایل الزامی است");

    const msg = await this.chatSvc.createMessage(user, dto);

    // broadcast به همه اعضای conversation
    this.io.to(`conv:${dto.conversationId}`).emit("new_message", msg);

    return { ok: true, messageId: msg.id.toString() };
  }

  // ─── علامت خوانده ──────────────────────────────────────────────────────────
  @SubscribeMessage("read_messages")
  async onRead(
    @ConnectedSocket() socket: Socket,
    @MessageBody() raw: unknown,
  ) {
    const user: AuthUser = (socket as any).user;
    if (!user) throw new WsException("unauthorized");

    const parsed = ReadSchema.safeParse(raw);
    if (!parsed.success) throw new WsException("invalid payload");

    await this.chatSvc.markRead(user.id, parsed.data.conversationId);

    // به طرف مقابل اطلاع بده
    socket.to(`conv:${parsed.data.conversationId}`).emit("messages_read", {
      conversationId: parsed.data.conversationId,
      readerId: user.id,
      at: new Date().toISOString(),
    });

    return { ok: true };
  }

  // ─── وضعیت تایپ ────────────────────────────────────────────────────────────
  @SubscribeMessage("typing")
  onTyping(
    @ConnectedSocket() socket: Socket,
    @MessageBody() raw: unknown,
  ) {
    const user: AuthUser = (socket as any).user;
    if (!user) return;
    const parsed = TypingSchema.safeParse(raw);
    if (!parsed.success) return;

    // به همه اعضا به‌جز فرستنده اطلاع بده
    socket.to(`conv:${parsed.data.conversationId}`).emit("typing_indicator", {
      conversationId: parsed.data.conversationId,
      userId: user.id,
      typing: parsed.data.typing,
    });
  }

  // ─── آنلاین بودن ───────────────────────────────────────────────────────────
  isOnline(userId: string): boolean {
    return (this.userSockets.get(userId)?.size ?? 0) > 0;
  }
}
