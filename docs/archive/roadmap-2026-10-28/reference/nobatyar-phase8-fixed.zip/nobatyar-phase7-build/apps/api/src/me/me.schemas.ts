import { z } from "zod";

export const updateProfileSchema = z.object({ fullName: z.string().trim().min(2).max(100) }).strict();

export const CONSENT_TYPES = ["PRIVACY_POLICY", "HEALTH_DATA_PROCESSING", "TERMS"] as const;
export const grantConsentSchema = z
  .object({ type: z.enum(CONSENT_TYPES), version: z.string().trim().min(1).max(32) })
  .strict();
export const consentTypeParamSchema = z.enum(CONSENT_TYPES);
