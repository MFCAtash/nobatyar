import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { Logger } from "@nestjs/common";
import { text } from "express";
import helmet from "helmet";
import { AppModule } from "./app.module";
import { loadAuthConfig } from "./config/auth.config";

async function bootstrap() {
  const cfg = loadAuthConfig(); // پیش از ساخت اپ: تنظیمات نامعتبر ⇒ توقف فوری
  const app = await NestFactory.create(AppModule);
  app.use(helmet());
  // webhook ی LiveKit: امضا روی بدنه‌ی «خام» محاسبه می‌شود؛ پیش از parser های JSON، فقط برای همین مسیر متن خام بخوان.
  app.use("/api/v1/video/webhook", text({ type: () => true, limit: "64kb" }));
  app.setGlobalPrefix("api/v1");
  app.enableShutdownHooks();

  // پشت reverse proxy: تعداد hop های مورد اعتماد (برای IP درست در rate limit)
  const hops = Number(process.env.TRUST_PROXY_HOPS ?? 0);
  const log = new Logger("bootstrap");
  const prod = process.env.NODE_ENV === "production";
  if (!Number.isInteger(hops) || hops < 0 || hops > 5) throw new Error("TRUST_PROXY_HOPS must be an integer 0..5");
  if (prod && hops === 0) log.warn("TRUST_PROXY_HOPS=0 در production: اگر پشت proxy هستید همه‌ی کاربران یک IP دیده می‌شوند و rate limit (OTP، triage، verify نسخه) مشترک می‌شود.");
  if (prod && process.env.ENABLE_WORKERS !== "true") log.warn("ENABLE_WORKERS!=true: این نمونه job های زمان‌بندی‌شده را اجرا نمی‌کند؛ مطمئن شوید نمونه‌ی worker دیگری فعال است.");
  if (hops > 0) (app.getHttpAdapter().getInstance() as { set: (k: string, v: unknown) => void }).set("trust proxy", hops);

  // CORS فقط برای مبدأهای مجاز؛ credentials برای کوکی refresh
  app.enableCors({
    origin: cfg.corsOrigins,
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization", "X-Nobatyar-Csrf"],
    methods: ["GET", "POST", "PATCH", "DELETE"],
    maxAge: 600,
  });

  await app.listen(Number(process.env.API_PORT ?? 3000), "0.0.0.0");
}
void bootstrap();
