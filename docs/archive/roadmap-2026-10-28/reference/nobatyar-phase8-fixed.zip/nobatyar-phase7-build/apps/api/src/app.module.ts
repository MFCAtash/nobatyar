import { Module } from "@nestjs/common";
import "./common/bigint-json";
import { AdminModule } from "./admin/admin.module";
import { PaymentModule } from "./payment/payment.module";
import { NotificationModule } from "./notifications/notification.module";
import { FamilyModule } from "./family/family.module";
import { CompareModule }  from "./compare/compare.module";
import { ChatModule }     from "./chat/chat.module";
import { RecordsModule }  from "./records/records.module";
import { StorageModule }  from "./storage/storage.module";
import { VideoModule }    from "./video/video.module";
import { HealthProfileModule } from "./health-profile/health-profile.module";
import { PrescriptionModule } from "./prescriptions/prescription.module";
import { SecondOpinionModule } from "./second-opinion/second-opinion.module";
import { SoapModule } from "./soap/soap.module";
import { TriageModule } from "./triage/triage.module";
import { AppointmentsModule } from "./appointments/appointments.module";
import { AuditModule } from "./audit/audit.module";
import { AuthModule } from "./auth/auth.module";
import { ConfigModule } from "./config/config.module";
import { CryptoModule } from "./crypto/crypto.module";
import { DoctorsModule } from "./doctors/doctors.module";
import { HealthController } from "./health.controller";
import { JobsModule } from "./jobs/jobs.module";
import { MeModule } from "./me/me.module";
import { PrismaModule } from "./prisma/prisma.module";
import { RedisModule } from "./redis/redis.module";
import { SchedulingModule } from "./scheduling/scheduling.module";
import { SmsModule } from "./sms/sms.module";

@Module({
  imports: [
    ConfigModule, SchedulingModule, CryptoModule, PrismaModule, AuditModule, RedisModule, SmsModule,
    AuthModule, MeModule, DoctorsModule, AppointmentsModule, JobsModule, AdminModule,
    PaymentModule,
    NotificationModule,
    FamilyModule,
    CompareModule,
    StorageModule,
    ChatModule,
    RecordsModule,
    VideoModule,
    // فاز ۸
    HealthProfileModule, TriageModule, SoapModule, PrescriptionModule, SecondOpinionModule,
  ],
  controllers: [HealthController],
})
export class AppModule {}
