import { Injectable, Inject, Logger, NotFoundException, ForbiddenException } from "@nestjs/common";
import type { Subject } from "rxjs";
import { PrismaService } from "../prisma/prisma.service";
import type { NotificationKind } from "@prisma/client";

export interface PushInput {
  kind:    NotificationKind;
  titleFa: string;
  bodyFa:  string;
  payload?: Record<string, unknown>;
}

/** Map از userId → SSE Subject (در حافظه فرآیند) */
export const SSE_SUBJECTS = Symbol("SSE_SUBJECTS");

@Injectable()
export class NotificationService {
  private readonly logger = new Logger(NotificationService.name);

  constructor(
    @Inject(PrismaService) private readonly prisma: PrismaService,
    @Inject(SSE_SUBJECTS)  private readonly subjects: Map<string, Subject<object>>,
  ) {}

  /** ذخیره اعلان در DB و push به SSE در صورت اتصال */
  async push(userId: string, input: PushInput): Promise<void> {
    try {
      const notif = await this.prisma.notification.create({
        data: {
          userId,
          kind:    input.kind,
          titleFa: input.titleFa,
          bodyFa:  input.bodyFa,
          payload: input.payload ?? {},
        },
        select: { id: true, kind: true, titleFa: true, bodyFa: true,
                  payload: true, createdAt: true },
      });

      // SSE: اگر کاربر متصل است فوراً بفرست
      const subj = this.subjects.get(userId);
      if (subj) {
        subj.next({ data: notif });
      }
    } catch (err) {
      // اعلان‌ها non-critical هستند — لاگ می‌کنیم ولی throw نمی‌کنیم
      this.logger.error(`push notification failed for ${userId}`, err);
    }
  }

  /** لیست اعلان‌های کاربر (صفحه‌بندی) */
  async list(userId: string, opts: { unreadOnly?: boolean; cursor?: string }) {
    const PAGE = 20;
    const where: any = { userId };
    if (opts.unreadOnly) where.readAt = null;
    if (opts.cursor)     where.id = { lt: opts.cursor };

    const items = await this.prisma.notification.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take:    PAGE + 1,
    });

    const hasMore = items.length > PAGE;
    return {
      items:   hasMore ? items.slice(0, PAGE) : items,
      hasMore,
      cursor:  hasMore ? items[PAGE - 1].id : null,
      unread:  await this.prisma.notification.count({ where: { userId, readAt: null } }),
    };
  }

  /** علامت خوانده */
  async markRead(userId: string, id: string): Promise<void> {
    const n = await this.prisma.notification.findUnique({ where: { id } });
    if (!n)              throw new NotFoundException();
    if (n.userId !== userId) throw new ForbiddenException();
    await this.prisma.notification.update({
      where: { id },
      data:  { readAt: new Date() },
    });
  }

  /** همه را خوانده کن */
  async markAllRead(userId: string): Promise<{ updated: number }> {
    const r = await this.prisma.notification.updateMany({
      where: { userId, readAt: null },
      data:  { readAt: new Date() },
    });
    return { updated: r.count };
  }
}
