import { Global, Module } from "@nestjs/common";
import { APP_GUARD } from "@nestjs/core";
import { AUTH_CONFIG, AuthConfig } from "../config/auth.config";
import { KV_STORE, KeyValueStore } from "../redis/kv-store";
import { SMS_PROVIDER, SmsProvider } from "../sms/sms.provider";
import { AuthController } from "./auth.controller";
import { AuthService } from "./auth.service";
import { ConsentGuard, JwtAuthGuard, RolesGuard } from "./guards";
import { OtpService } from "./otp.service";
import { TokenService } from "./token.service";

@Global()
@Module({
  controllers: [AuthController],
  providers: [
    {
      provide: OtpService,
      inject: [KV_STORE, SMS_PROVIDER, AUTH_CONFIG],
      useFactory: (kv: KeyValueStore, sms: SmsProvider, cfg: AuthConfig) => new OtpService(kv, sms, cfg),
    },
    { provide: TokenService, inject: [AUTH_CONFIG], useFactory: (cfg: AuthConfig) => new TokenService(cfg) },
    AuthService,
    // ترتیب مهم است: ابتدا احراز هویت، سپس نقش، سپس رضایت
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
    { provide: APP_GUARD, useClass: ConsentGuard },
  ],
  exports: [TokenService, AuthService],
})
export class AuthModule {}
