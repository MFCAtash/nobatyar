import { ForbiddenException, Inject, Injectable, NotFoundException } from "@nestjs/common";
import { z } from "zod";
import { FIELD_CRYPTO, FieldCrypto, aad } from "../crypto";
import { PrismaService } from "../prisma/prisma.service";
import type { AuthUser } from "../common/decorators";

export const FamilyMemberSchema = z.object({
  fullName:   z.string().min(2).max(60),
  relation:   z.string().min(1).max(30),
  birthYear:  z.number().int().min(1300).max(1420).optional(),
  nationalId: z.string().regex(/^\d{10}$/, "کد ملی باید ۱۰ رقم باشد").optional(),
});
export type FamilyMemberInput = z.infer<typeof FamilyMemberSchema>;

@Injectable()
export class FamilyService {
  constructor(
    @Inject(PrismaService) private readonly prisma: PrismaService,
    @Inject(FIELD_CRYPTO)  private readonly crypto:  FieldCrypto,
  ) {}

  async list(user: AuthUser) {
    const members = await this.prisma.familyMember.findMany({
      where:   { ownerId: user.id },
      orderBy: { createdAt: "asc" },
      select:  { id: true, fullName: true, relation: true, birthYear: true,
                 nationalId: true, createdAt: true },
    });
    return Promise.all(members.map(async (m) => ({
      id:         m.id,
      fullName:   m.fullName,
      relation:   m.relation,
      birthYear:  m.birthYear,
      /** کد ملی رمزگشایی می‌شود فقط برای نمایش مالک — پیش از ارسال به client ماسک می‌شود */
      nationalIdMasked: m.nationalId
        ? (await this.crypto.decrypt(m.nationalId, aad("family", m.id)))
            .toString("utf-8").replace(/^(.{6})/, "****")
        : null,
      createdAt: m.createdAt,
    })));
  }

  async add(user: AuthUser, dto: FamilyMemberInput) {
    let nationalIdEnc: Buffer | undefined;
    if (dto.nationalId) {
      nationalIdEnc = await this.crypto.encrypt(
        Buffer.from(dto.nationalId, "utf-8"),
        aad("family-national-id", user.id),
      );
    }
    return this.prisma.familyMember.create({
      data: {
        ownerId:    user.id,
        fullName:   dto.fullName,
        relation:   dto.relation,
        birthYear:  dto.birthYear,
        nationalId: nationalIdEnc,
      },
      select: { id: true, fullName: true, relation: true, birthYear: true, createdAt: true },
    });
  }

  async remove(user: AuthUser, id: string) {
    const m = await this.prisma.familyMember.findUnique({ where: { id } });
    if (!m)                throw new NotFoundException();
    if (m.ownerId !== user.id) throw new ForbiddenException();
    await this.prisma.familyMember.delete({ where: { id } });
    return { deleted: true };
  }

  async update(user: AuthUser, id: string, dto: Partial<FamilyMemberInput>) {
    const m = await this.prisma.familyMember.findUnique({ where: { id } });
    if (!m)                throw new NotFoundException();
    if (m.ownerId !== user.id) throw new ForbiddenException();

    let nationalIdEnc: Buffer | undefined;
    if (dto.nationalId) {
      nationalIdEnc = await this.crypto.encrypt(
        Buffer.from(dto.nationalId, "utf-8"),
        aad("family-national-id", user.id),
      );
    }

    return this.prisma.familyMember.update({
      where:  { id },
      data: {
        fullName:   dto.fullName,
        relation:   dto.relation,
        birthYear:  dto.birthYear,
        ...(nationalIdEnc ? { nationalId: nationalIdEnc } : {}),
      },
      select: { id: true, fullName: true, relation: true, birthYear: true, createdAt: true },
    });
  }
}
