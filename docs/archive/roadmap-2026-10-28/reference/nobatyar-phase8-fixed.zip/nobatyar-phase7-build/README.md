# نوبتیار

پلتفرم نوبت‌دهی و مشاوره‌ی آنلاین پزشکی (RTL، فارسی).

## ساختار
```
apps/web          فرانت Next.js (RTL فارسی) — فاز ۴؛ جزئیات: docs/phase-4.md
apps/api          بک‌اند NestJS (Prisma/RLS، رمزنگاری فیلد، Audit، OTP/JWT، نقش‌ها، تأیید پزشک)
packages/shared   تایپ‌ها و قواعد مشترک (نقش‌ها، ماشین وضعیت نوبت)
infra/            تنظیمات زیرساخت (Postgres init)
docs/             مدل تهدید، طبقه‌بندی داده، سیاست حریم خصوصی، ER، قواعد نوبت
```

## شروع سریع
```bash
corepack enable
pnpm install
cp .env.example .env        # مقادیر را عوض کنید
pnpm --filter @nobatyar/api gen:keys   # کلیدها را در .env بگذارید
pnpm infra:up               # Postgres + Redis + MinIO + LiveKit
pnpm --filter @nobatyar/api db:init    # یک‌بار؛ جزئیات: docs/phase-1.md
pnpm --filter @nobatyar/shared build
pnpm --filter @nobatyar/api dev
curl localhost:3000/health
```

## دستورها
| دستور | کار |
|---|---|
| `pnpm lint / typecheck / test / build` | کنترل کیفیت (Turborepo) |
| `pnpm infra:up / infra:down / infra:reset` | مدیریت زیرساخت محلی |

## امنیت
- هرگز `.env` را commit نکنید؛ gitleaks در CI فعال است.
- داده‌ی سلامت (HEALTH) هرگز در لاگ نیاید؛ نگاه کنید به `docs/data-classification.md`.

## نقشه‌ی راه
فاز ۰ ✅ ← فاز ۱ (`docs/phase-1.md`) ← فاز ۲ Auth و نقش‌ها (`docs/phase-2.md`) ← فاز ۳ چرخه‌ی نوبت (`docs/phase-3.md`) ← فاز ۴ فرانت‌اند (`docs/phase-4.md`) ← فاز ۵: پرداخت ← فاز ۶ چت/آپلود/پرونده (`docs/phase-6.md`) ← فاز ۷ ویزیت ویدئویی WebRTC/LiveKit (`docs/phase-7.md`) ← **فاز ۸ پرونده‌ی سلامت، triage، نظر دوم، SOAP، نسخه (`docs/phase-8.md`)** ← فاز ۹ (سخت‌سازی، Redis pub/sub، load test) ← فاز ۱۰ (بتا عمومی، monitoring، SLA)
چک‌لیست فاز ۰: `docs/phase-0-checklist.md`
